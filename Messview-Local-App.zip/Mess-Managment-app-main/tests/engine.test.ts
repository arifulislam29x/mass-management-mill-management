import assert from 'node:assert/strict';
import { initStore, memoryDriver, flush, __resetForTests, getState } from '../src/lib/local/store.ts';
import { handleRequest as h } from '../src/lib/local/engine.ts';

let n = 0;
const ok = (name: string, fn: () => void) => { fn(); n++; console.log('ok', name); };
const throwsStatus = (status: number, fn: () => unknown) => {
  try { fn(); } catch (e: any) { assert.equal(e.status, status, e.message); return e.message as string; }
  assert.fail('expected throw ' + status);
};

const drv = memoryDriver();
await initStore(drv);
const M = '2026-11';

const a = h('POST', '/api/admin/members', { name: 'Rahim', joinDate: '2026-11-01' }) as any;
const b = h('POST', '/api/admin/members', { name: 'Karim', joinDate: '2026-11-01', phone: '017' }) as any;
ok('members created', () => assert.deepEqual([a.id, b.id], [1, 2]));
ok('validation', () => throwsStatus(400, () => h('POST', '/api/admin/members', { name: 'x', joinDate: '2026-11-01' })));

h('POST', '/api/admin/deposits', { memberId: 1, depositDate: '2026-11-02', amount: 1000, paymentMethod: 'cash' });
h('POST', '/api/admin/deposits', { memberId: 2, depositDate: '2026-11-02', amount: 500, paymentMethod: 'bkash' });
h('POST', '/api/admin/bazar', { bazarDate: '2026-11-03', title: 'Weekly', items: [
  { itemName: 'Rice', quantity: 10, unit: 'kg', totalPrice: 700 }, { itemName: 'Egg', quantity: 12, unit: 'pc', totalPrice: 140 }] });
h('POST', '/api/admin/expenses', { expenseDate: '2026-11-03', expenseType: 'common', title: 'Gas', amount: 160 });
h('POST', '/api/admin/expenses', { expenseDate: '2026-11-03', expenseType: 'individual', memberId: 2, title: 'Snack', amount: 50 });
h('POST', '/api/admin/meals/bulk', { mealDate: '2026-11-03', entries: [
  { memberId: 1, breakfast: 0, lunch: 1, dinner: 1 }, { memberId: 2, breakfast: 0, lunch: 1, dinner: 0 }] });

const ov = h('GET', `/api/public/overview?month=${M}`) as any;
ok('summary math', () => {
  assert.equal(ov.totals.totalMeals, 3);
  assert.equal(ov.totals.bazarExpense, 840);
  assert.equal(ov.totals.totalCommonExpense, 1000);
  assert.equal(ov.totals.mealRate, 333.33);
  const r = ov.members.find((m: any) => m.name === 'Rahim');
  assert.equal(r.mealCost, 666.67);
  assert.equal(r.balance, 333.33);
  const k = ov.members.find((m: any) => m.name === 'Karim');
  assert.equal(k.totalExpense, 383.33);
  assert.equal(ov.totals.remainingBalance, 1500 - 1050);
});
ok('meal upsert', () => {
  h('POST', '/api/admin/meals/bulk', { mealDate: '2026-11-03', entries: [{ memberId: 1, breakfast: 0, lunch: 2, dinner: 1 }] });
  assert.equal(getState().meals.length, 2);
  assert.equal(getState().meals.find((m) => m.member_id === 1)!.total_meal, 3);
});
ok('daily sheet', () => {
  const m = h('GET', '/api/public/meals?month=2026-11&date=2026-11-03') as any;
  assert.equal(m.dailySheet.length, 2);
});
ok('bazar list + search', () => {
  const r = h('GET', '/api/public/bazar?month=2026-11&search=egg') as any;
  assert.equal(r.transactions.length, 1);
  assert.equal(r.totalBazarExpense, 840);
});
ok('deposits running', () => {
  h('POST', '/api/admin/deposits', { memberId: 1, depositDate: '2026-11-05', amount: 250, paymentMethod: 'cash' });
  const d = h('GET', `/api/public/deposits?month=${M}`) as any;
  assert.equal(d.deposits[0].cumulativeDeposit, 1250);
  assert.equal(d.deposits[0].previousDeposit, 1000);
});
ok('member detail', () => {
  const d = h('GET', `/api/public/members/2?month=${M}`) as any;
  assert.equal(d.deposits.length, 1);
  assert.equal(d.expenses.length, 1);
  throwsStatus(404, () => h('GET', '/api/public/members/99'));
});
ok('persist & reload', async () => {});
await flush();
const saved = drv.data.get('state');
assert.ok(saved); n++;

ok('close month freezes + blocks writes', () => {
  h('POST', '/api/admin/reports/close', { monthKey: M });
  const msg = throwsStatus(409, () => h('POST', '/api/admin/deposits', { memberId: 1, depositDate: '2026-11-09', amount: 5, paymentMethod: 'cash' }));
  assert.match(msg, /closed/);
  throwsStatus(409, () => h('DELETE', '/api/admin/meals/1'));
  throwsStatus(409, () => h('POST', '/api/admin/reports/close', { monthKey: M }));
  const o = h('GET', `/api/public/overview?month=${M}`) as any;
  assert.equal(o.isClosed, true);
  assert.equal(o.members.length, 2);
  h('POST', '/api/admin/reports/reopen', { monthKey: M });
  h('POST', '/api/admin/deposits', { memberId: 1, depositDate: '2026-11-09', amount: 5, paymentMethod: 'cash' });
});
ok('failed write rolls back', () => {
  const before = JSON.stringify(getState().members);
  throwsStatus(404, () => h('POST', '/api/admin/meals/bulk', { mealDate: '2026-11-04', entries: [
    { memberId: 1, breakfast: 0, lunch: 1, dinner: 1 }, { memberId: 77, breakfast: 0, lunch: 1, dinner: 1 }] }));
  assert.equal(getState().meals.filter((m) => m.meal_date === '2026-11-04').length, 0);
  assert.equal(JSON.stringify(getState().members), before);
});

const bk = h('GET', '/api/admin/backup') as any;
ok('backup shape', () => { assert.equal(bk.version, 1); assert.equal(bk.tables.members.length, 2); });
ok('settings', () => {
  h('PUT', '/api/admin/settings', { mess_name: 'Z', mess_name_bn: 'জ', currency_symbol: '$', enable_breakfast: 'true', default_language: 'en' });
  assert.equal((h('GET', '/api/info') as any).name, 'Z');
  throwsStatus(400, () => h('PUT', '/api/admin/settings', { mess_name: '' }));
});
ok('delete member cascades', () => {
  h('DELETE', '/api/admin/members/2');
  const s = getState();
  assert.equal(s.deposits.some((d) => d.member_id === 2), false);
  assert.equal(s.individual_expenses.some((d) => d.member_id === 2), false);
  assert.equal(s.meals.some((d) => d.member_id === 2), false);
});
ok('restore round-trip', () => {
  h('POST', '/api/admin/restore', bk);
  const s = getState();
  assert.equal(s.members.length, 2);
  assert.equal(s.deposits.length, bk.tables.deposits.length);
  const id = (h('POST', '/api/admin/members', { name: 'Newbie', joinDate: '2026-11-01' }) as any).id;
  assert.ok(id > 2);
  const o = h('GET', `/api/public/overview?month=${M}`) as any;
  assert.equal(o.totals.mealRate, 250);
});
ok('restore rejects bad data and keeps state', () => {
  const bad = JSON.parse(JSON.stringify(bk));
  bad.tables.deposits[0].member_id = 999;
  const before = getState().members.length;
  throwsStatus(400, () => h('POST', '/api/admin/restore', bad));
  throwsStatus(400, () => h('POST', '/api/admin/restore', { version: 2 }));
  assert.equal(getState().members.length, before);
});
ok('demo load/clear', () => {
  h('POST', '/api/admin/demo/load');
  assert.equal(getState().members.length, 4);
  const o = h('GET', '/api/public/overview') as any;
  assert.ok(o.totals.mealRate > 0);
  h('POST', '/api/admin/demo/clear');
  assert.equal(getState().members.length, 0);
});
ok('months list', () => {
  const r = h('GET', '/api/public/months') as any;
  assert.ok(r.months.includes(r.currentMonth));
});
ok('audit', () => {
  const r = h('GET', '/api/admin/audit-logs?limit=5') as any;
  assert.equal(r.logs.length, 5);
});
ok('unknown route', () => throwsStatus(404, () => h('GET', '/api/nope')));

// reload from the saved bytes
await flush();
__resetForTests();
await initStore(drv);
ok('reload keeps data', () => assert.ok(Array.isArray(getState().members)));
console.log(`\n${n} checks passed`);
process.exit(0);
