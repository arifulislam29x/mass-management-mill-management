import assert from 'node:assert/strict';
const mem = new Map<string, string>();
(globalThis as any).window = globalThis;
(globalThis as any).localStorage = {
  getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null),
  setItem: (k: string, v: string) => void mem.set(k, v),
  removeItem: (k: string) => void mem.delete(k),
  key: (i: number) => [...mem.keys()][i] ?? null,
  get length() { return mem.size; },
};
const S = await import('../src/lib/local/store.ts');
const { handleRequest: h } = await import('../src/lib/local/engine.ts');
const { setPin, verifyPin, hasPin, removePin } = await import('../src/lib/local/lock.ts');

await S.initStore();
h('POST', '/api/admin/members', { name: 'Rahim', joinDate: '2026-11-01' });
h('POST', '/api/admin/members', { name: 'Karim', joinDate: '2026-11-01' });
await S.flush();
assert.ok([...mem.keys()].some((k) => k.startsWith('mv:snap:')), 'daily snapshot written');
assert.ok(mem.has('mv:state') && mem.has('mv:state.prev'));
console.log('ok persisted + snapshot + prev');

S.__resetForTests(); await S.initStore();
assert.equal(S.getState().members.length, 2); console.log('ok reload');

// corrupt the live copy -> previous good copy is used and the bad bytes are kept
await S.flush();
mem.set('mv:state', '{broken');
S.__resetForTests(); await S.initStore();
assert.equal(S.getState().members.length >= 1, true);
assert.ok([...mem.keys()].some((k) => k.startsWith('mv:state.corrupt.')));
console.log('ok corrupt recovery keeps bad copy');

// both corrupt -> error, nothing overwritten
mem.set('mv:state', '{x'); mem.set('mv:state.prev', '{y');
S.__resetForTests();
await assert.rejects(S.initStore(), (e: any) => e instanceof S.StoreCorruptError);
assert.equal(mem.get('mv:state'), '{x'); console.log('ok double-corrupt refuses to overwrite');

// PIN
mem.clear(); S.__resetForTests(); await S.initStore();
(globalThis as any).crypto ??= (await import('node:crypto')).webcrypto;
await setPin('4821');
assert.ok(hasPin()); assert.equal(await verifyPin('4821'), true); assert.equal(await verifyPin('1111'), false);
S.__resetForTests(); await S.initStore();
assert.equal(hasPin(), true); assert.equal(await verifyPin('4821'), true);
await removePin(); assert.equal(hasPin(), false);
console.log('ok pin');
process.exit(0);
