export class ApiError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/** Human-friendly, localized text for any error (never shows raw stack traces). */
export function errorText(err: unknown, bn: boolean): string {
  if (err instanceof Error && err.message) return err.message.slice(0, 300);
  return bn ? 'কিছু একটা সমস্যা হয়েছে' : 'Something went wrong';
}
