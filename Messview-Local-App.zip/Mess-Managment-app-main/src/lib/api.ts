/**
 * Thin client over the on-device engine. The screens call `apiRequest('/api/...')`
 * exactly like before, but the request is answered locally — no network involved.
 */
import { ApiError, errorText } from './errors.ts';
import { handleRequest } from './local/engine.ts';

export { ApiError, errorText };

export async function apiRequest<T>(
  path: string,
  options: { method?: string; body?: unknown; token?: string | null } = {}
): Promise<T> {
  const method = (options.method || 'GET').toUpperCase();
  // Round-trip through JSON so callers never share references with the in-memory ledger.
  const body = options.body === undefined ? undefined : JSON.parse(JSON.stringify(options.body));
  const result = handleRequest(method, path, body);
  return (result === undefined ? undefined : JSON.parse(JSON.stringify(result))) as T;
}
