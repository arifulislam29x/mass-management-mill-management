/** Optional app-lock PIN. Protects the screen only; the saved data itself is not encrypted. */
import { getMeta, updateMeta } from './store.ts';

const enc = new TextEncoder();

function toHex(buf: ArrayBuffer | Uint8Array): string {
  return [...new Uint8Array(buf as ArrayBuffer)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function derive(pin: string, salt: string): Promise<string> {
  const subtle = typeof crypto !== 'undefined' ? crypto.subtle : undefined;
  if (subtle) {
    const key = await subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
    const bits = await subtle.deriveBits(
      { name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: 120_000 },
      key,
      256
    );
    return toHex(bits);
  }
  // Very old / insecure-context fallback (FNV-style), still better than plain text.
  let h = 2166136261;
  for (const c of salt + pin) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0;
  return `f${h.toString(16)}`;
}

export function hasPin(): boolean {
  return Boolean(getMeta().pinHash);
}

export async function setPin(pin: string): Promise<void> {
  if (!/^\d{4,8}$/.test(pin)) throw new Error('PIN must be 4–8 digits');
  const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
  await updateMeta({ pinSalt: salt, pinHash: await derive(pin, salt) });
}

export async function verifyPin(pin: string): Promise<boolean> {
  const { pinHash, pinSalt } = getMeta();
  if (!pinHash || !pinSalt) return true;
  return (await derive(pin, pinSalt)) === pinHash;
}

export async function removePin(): Promise<void> {
  await updateMeta({ pinHash: null, pinSalt: null });
}
