/**
 * The "server", running inside the app.
 *
 * `handleRequest` implements the same endpoints (and the same validation, rounding and
 * month-closing rules) the old Node/SQLite server had, but against the on-device store.
 * The screens keep calling `apiRequest('/api/...')`; nothing leaves the phone.
 */
import { z } from 'zod';
import { ApiError } from '../errors.ts';
import {
  type AuditRow,
  type BazarItemRow,
  type BazarRow,
  type DepositRow,
  type ExpenseRow,
  type LedgerState,
  type MealRow,
  type MemberRow,
  type ReportRow,
  DEFAULT_SETTINGS,
  TABLES,
  emptyState,
  getState,
  nextId,
  replaceState,
  transaction,
} from './store.ts';

const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
const monthRegex = /^\d{4}-\d{2}$/;
const ACTOR = 'me';

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

export function roundMoney(val: number): number {
  return Math.round((val + Number.EPSILON) * 100) / 100;
}

function nowSql(): string {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

export function getCurrentMonthKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function monthKeyFromDate(d: string): string {
  return d.slice(0, 7);
}

function isValidSafePhotoUrl(url: string): boolean {
  const trimmed = url.trim();
  if (!trimmed) return true;
  if (/^data:image\/(png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=]+$/i.test(trimmed)) {
    return trimmed.length <= 700_000;
  }
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

const cmpNoCase = (a: string, b: string) => {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  return x < y ? -1 : x > y ? 1 : 0;
};
const cmpStr = (a: string, b: string) => (a < b ? -1 : a > b ? 1 : 0);

function bad(message: string): never {
  throw new ApiError(400, message);
}
function notFound(message: string): never {
  throw new ApiError(404, message);
}

function parseBody<T>(schema: z.ZodType<T>, body: unknown, fallback: string): T {
  const parsed = schema.safeParse(body);
  if (!parsed.success) bad(parsed.error.issues[0]?.message || fallback);
  return parsed.data;
}

function parseId(raw: string, label: string): number {
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) bad(`Invalid ${label} ID`);
  return id;
}

function audit(
  s: LedgerState,
  action: string,
  entityType: string,
  summary: string,
  entityId: string | number = ''
): void {
  const row: AuditRow = {
    id: nextId('audit_logs'),
    admin_username: ACTOR,
    action,
    entity_type: entityType,
    entity_id: String(entityId),
    summary,
    ip_address: '',
    created_at: nowSql(),
  };
  s.audit_logs.push(row);
  // Keep the log bounded so the saved document never grows without limit.
  if (s.audit_logs.length > 1500) s.audit_logs.splice(0, s.audit_logs.length - 1000);
}

function assertMonthOpen(s: LedgerState, monthKey: string): void {
  if (s.monthly_reports.some((r) => r.month_key === monthKey && r.is_closed === 1)) {
    throw new ApiError(
      409,
      `Month ${monthKey} is closed. Reopen it from Monthly Reports before modifying records.`
    );
  }
}

function resolveMonth(q: URLSearchParams): string {
  const m = q.get('month');
  return m && monthRegex.test(m) ? m : getCurrentMonthKey();
}

function sum<T>(rows: T[], pick: (r: T) => number): number {
  return rows.reduce((a, r) => a + pick(r), 0);
}

/* ------------------------------------------------------------------ */
/* monthly summary (port of server/calculations.ts)                    */
/* ------------------------------------------------------------------ */

export interface MemberMonthlySummary {
  memberId: number;
  name: string;
  phone: string;
  photoUrl: string;
  joinDate: string;
  isActive: boolean;
  notes: string;
  totalDeposit: number;
  breakfastCount: number;
  lunchCount: number;
  dinnerCount: number;
  extraMealCount: number;
  totalMeals: number;
  mealCost: number;
  individualExpense: number;
  totalExpense: number;
  balance: number;
}

function getSettingsMap(s: LedgerState): Record<string, string> {
  return { ...s.settings };
}

function availableMonthKeys(s: LedgerState): string[] {
  const set = new Set<string>();
  for (const r of s.meals) set.add(r.month_key);
  for (const r of s.bazar_transactions) set.add(r.month_key);
  for (const r of s.deposits) set.add(r.month_key);
  for (const r of s.individual_expenses) set.add(r.month_key);
  for (const r of s.monthly_reports) set.add(r.month_key);
  return [...set];
}

export function getAvailableMonths(s: LedgerState, currentMonthKey: string): string[] {
  const set = new Set<string>(availableMonthKeys(s));
  set.add(currentMonthKey);
  return [...set].sort((a, b) => cmpStr(b, a));
}

function computeChartSeries(s: LedgerState, monthKey: string) {
  const dateMap = new Map<
    string,
    { bazar: number; commonExtra: number; individualExtra: number; meals: number }
  >();
  const ensure = (dt: string) => {
    let e = dateMap.get(dt);
    if (!e) {
      e = { bazar: 0, commonExtra: 0, individualExtra: 0, meals: 0 };
      dateMap.set(dt, e);
    }
    return e;
  };
  for (const r of s.bazar_transactions) if (r.month_key === monthKey) ensure(r.bazar_date).bazar += r.total_amount;
  for (const r of s.individual_expenses) {
    if (r.month_key !== monthKey) continue;
    const e = ensure(r.expense_date);
    if (r.expense_type === 'common') e.commonExtra += r.amount;
    else e.individualExtra += r.amount;
  }
  for (const r of s.meals) if (r.month_key === monthKey) ensure(r.meal_date).meals += r.total_meal;

  const dailyExpenses = [...dateMap.entries()]
    .sort(([a], [b]) => cmpStr(a, b))
    .map(([date, v]) => ({
      date,
      bazar: roundMoney(v.bazar),
      commonExtra: roundMoney(v.commonExtra),
      individualExtra: roundMoney(v.individualExtra),
      total: roundMoney(v.bazar + v.commonExtra + v.individualExtra),
      meals: roundMoney(v.meals),
    }));

  const keys = availableMonthKeys(s).sort((a, b) => cmpStr(b, a)).slice(0, 6).reverse();
  if (!keys.includes(monthKey)) {
    keys.push(monthKey);
    keys.sort();
  }
  const monthlyHistory = keys.slice(-6).map((mk) => {
    const dep = sum(s.deposits.filter((r) => r.month_key === mk), (r) => r.amount);
    const baz = sum(s.bazar_transactions.filter((r) => r.month_key === mk), (r) => r.total_amount);
    const com = sum(
      s.individual_expenses.filter((r) => r.month_key === mk && r.expense_type === 'common'),
      (r) => r.amount
    );
    const ind = sum(
      s.individual_expenses.filter((r) => r.month_key === mk && r.expense_type === 'individual'),
      (r) => r.amount
    );
    const mls = sum(s.meals.filter((r) => r.month_key === mk), (r) => r.total_meal);
    const commonTotal = baz + com;
    return {
      monthKey: mk,
      totalDeposit: roundMoney(dep),
      totalExpense: roundMoney(commonTotal + ind),
      bazarExpense: roundMoney(baz),
      totalMeals: roundMoney(mls),
      mealRate: mls > 0 ? roundMoney(commonTotal / mls) : 0,
    };
  });
  return { dailyExpenses, monthlyHistory };
}

export function computeMonthlySummary(s: LedgerState, monthKey: string) {
  const settings = getSettingsMap(s);
  const closed = s.monthly_reports.find((r) => r.month_key === monthKey && r.is_closed === 1);
  const charts = computeChartSeries(s, monthKey);

  if (closed) {
    let snapshotMembers: MemberMonthlySummary[] = [];
    try {
      const parsed = JSON.parse(closed.snapshot_json) as { members?: MemberMonthlySummary[] };
      snapshotMembers = Array.isArray(parsed.members) ? parsed.members : [];
    } catch {
      snapshotMembers = [];
    }
    return {
      monthKey,
      isClosed: true,
      closedAt: closed.closed_at,
      closedBy: closed.closed_by,
      settings,
      totals: {
        memberCount: closed.total_members,
        activeMemberCount: snapshotMembers.filter((m) => m.isActive).length,
        totalDeposit: closed.total_deposit,
        bazarExpense: closed.total_bazar_expense,
        commonExtraExpense: closed.total_common_extra_expense,
        totalCommonExpense: roundMoney(closed.total_bazar_expense + closed.total_common_extra_expense),
        totalIndividualExpense: closed.total_individual_expense,
        totalMessExpense: closed.total_expense,
        totalMeals: closed.total_meals,
        mealRate: closed.meal_rate,
        remainingBalance: closed.remaining_balance,
      },
      members: snapshotMembers,
      charts,
    };
  }

  const allMembers = [...s.members].sort(
    (a, b) => b.is_active - a.is_active || cmpNoCase(a.name, b.name)
  );

  const mealMap = new Map<
    number,
    { breakfast: number; lunch: number; dinner: number; extra: number; total: number }
  >();
  for (const r of s.meals) {
    if (r.month_key !== monthKey) continue;
    const e = mealMap.get(r.member_id) ?? { breakfast: 0, lunch: 0, dinner: 0, extra: 0, total: 0 };
    e.breakfast += r.breakfast;
    e.lunch += r.lunch;
    e.dinner += r.dinner;
    e.extra += r.extra_meal;
    e.total += r.total_meal;
    mealMap.set(r.member_id, e);
  }
  const depositMap = new Map<number, number>();
  for (const r of s.deposits) {
    if (r.month_key === monthKey) depositMap.set(r.member_id, (depositMap.get(r.member_id) ?? 0) + r.amount);
  }
  const indivMap = new Map<number, number>();
  for (const r of s.individual_expenses) {
    if (r.month_key === monthKey && r.expense_type === 'individual' && r.member_id !== null) {
      indivMap.set(r.member_id, (indivMap.get(r.member_id) ?? 0) + r.amount);
    }
  }

  const relevant = allMembers.filter(
    (m) => m.is_active === 1 || mealMap.has(m.id) || depositMap.has(m.id) || indivMap.has(m.id)
  );

  const totalMeals = roundMoney(sum([...mealMap.values()], (r) => r.total));
  const bazarExpense = roundMoney(
    sum(s.bazar_transactions.filter((r) => r.month_key === monthKey), (r) => r.total_amount)
  );
  const commonExtraExpense = roundMoney(
    sum(
      s.individual_expenses.filter((r) => r.month_key === monthKey && r.expense_type === 'common'),
      (r) => r.amount
    )
  );
  const totalCommonExpense = roundMoney(bazarExpense + commonExtraExpense);
  const mealRate = totalMeals > 0 ? roundMoney(totalCommonExpense / totalMeals) : 0;
  const exactRate = totalMeals > 0 ? totalCommonExpense / totalMeals : 0;

  let totalDeposit = 0;
  let totalIndividualExpense = 0;
  const members: MemberMonthlySummary[] = relevant.map((m) => {
    const ms = mealMap.get(m.id);
    const deposit = roundMoney(depositMap.get(m.id) ?? 0);
    const indiv = roundMoney(indivMap.get(m.id) ?? 0);
    const mTotal = roundMoney(ms?.total ?? 0);
    const mealCost = roundMoney(mTotal * exactRate);
    const totalExpense = roundMoney(mealCost + indiv);
    totalDeposit += deposit;
    totalIndividualExpense += indiv;
    return {
      memberId: m.id,
      name: m.name,
      phone: m.phone || '',
      photoUrl: m.photo_url || '',
      joinDate: m.join_date,
      isActive: m.is_active === 1,
      notes: m.notes || '',
      totalDeposit: deposit,
      breakfastCount: roundMoney(ms?.breakfast ?? 0),
      lunchCount: roundMoney(ms?.lunch ?? 0),
      dinnerCount: roundMoney(ms?.dinner ?? 0),
      extraMealCount: roundMoney(ms?.extra ?? 0),
      totalMeals: mTotal,
      mealCost,
      individualExpense: indiv,
      totalExpense,
      balance: roundMoney(deposit - totalExpense),
    };
  });

  totalDeposit = roundMoney(totalDeposit);
  totalIndividualExpense = roundMoney(totalIndividualExpense);
  const totalMessExpense = roundMoney(totalCommonExpense + totalIndividualExpense);

  return {
    monthKey,
    isClosed: false,
    closedAt: null,
    closedBy: null,
    settings,
    totals: {
      memberCount: relevant.length,
      activeMemberCount: allMembers.filter((m) => m.is_active === 1).length,
      totalDeposit,
      bazarExpense,
      commonExtraExpense,
      totalCommonExpense,
      totalIndividualExpense,
      totalMessExpense,
      totalMeals,
      mealRate,
      remainingBalance: roundMoney(totalDeposit - totalMessExpense),
    },
    members,
    charts,
  };
}

/* ------------------------------------------------------------------ */
/* schemas (identical rules to the old server)                         */
/* ------------------------------------------------------------------ */

const memberSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters').max(80),
  phone: z.string().trim().max(30).optional().default(''),
  photoUrl: z
    .string()
    .trim()
    .optional()
    .default('')
    .refine((v) => isValidSafePhotoUrl(v), 'Invalid or unsupported photo URL/format'),
  joinDate: z.string().regex(dateRegex, 'Valid join date (YYYY-MM-DD) is required'),
  isActive: z.boolean().optional().default(true),
  notes: z.string().trim().max(300).optional().default(''),
});

const mealEntrySchema = z.object({
  memberId: z.number().int().positive(),
  breakfast: z.number().min(0).max(20),
  lunch: z.number().min(0).max(20),
  dinner: z.number().min(0).max(20),
  extraMeal: z.number().min(0).max(20).optional().default(0),
  note: z.string().trim().max(200).optional().default(''),
});
const bulkMealsSchema = z.object({
  mealDate: z.string().regex(dateRegex, 'Valid date (YYYY-MM-DD) is required'),
  entries: z.array(mealEntrySchema).min(1),
});

const bazarItemSchema = z.object({
  itemName: z.string().trim().min(1, 'Item name required').max(100),
  quantity: z.number().positive('Quantity must be greater than 0').max(100000),
  unit: z.string().trim().min(1).max(30),
  unitPrice: z.number().min(0).max(10000000).optional(),
  totalPrice: z.number().min(0).max(10000000),
});
const bazarTxSchema = z.object({
  bazarDate: z.string().regex(dateRegex, 'Valid bazar date (YYYY-MM-DD) required'),
  title: z.string().trim().min(2, 'Bazar title required').max(120),
  shopperMemberId: z.number().int().positive().nullable().optional(),
  shopperName: z.string().trim().max(80).optional().default(''),
  notes: z.string().trim().max(300).optional().default(''),
  items: z.array(bazarItemSchema).min(1, 'At least one bazar item is required'),
});

const expenseSchema = z
  .object({
    expenseDate: z.string().regex(dateRegex, 'Valid expense date required'),
    expenseType: z.enum(['individual', 'common']),
    memberId: z.number().int().positive().nullable().optional(),
    title: z.string().trim().min(2, 'Description required').max(140),
    amount: z.number().positive('Amount must be greater than 0').max(10000000),
    notes: z.string().trim().max(300).optional().default(''),
  })
  .refine((d) => d.expenseType === 'common' || (d.memberId !== null && d.memberId !== undefined), {
    message: 'Member selection is required for individual expenses',
  });

const depositSchema = z.object({
  memberId: z.number().int().positive(),
  depositDate: z.string().regex(dateRegex, 'Valid deposit date required'),
  amount: z.number().positive('Deposit amount must be greater than 0').max(10000000),
  paymentMethod: z.enum(['cash', 'bkash', 'nagad', 'bank', 'other']),
  note: z.string().trim().max(300).optional().default(''),
});

const settingsSchema = z.object({
  mess_name: z.string().trim().min(1).max(80),
  mess_name_bn: z.string().trim().min(1).max(80),
  currency_symbol: z.string().trim().min(1).max(5),
  enable_breakfast: z.enum(['true', 'false']),
  default_language: z.enum(['bn', 'en']),
});

const restoreSchema = z.object({
  version: z.literal(1),
  tables: z.object({
    settings: z.array(z.object({ key: z.string(), value: z.string() })).optional().default([]),
    members: z.array(z.record(z.string(), z.unknown())),
    meals: z.array(z.record(z.string(), z.unknown())),
    bazar_transactions: z.array(z.record(z.string(), z.unknown())),
    bazar_items: z.array(z.record(z.string(), z.unknown())),
    individual_expenses: z.array(z.record(z.string(), z.unknown())),
    deposits: z.array(z.record(z.string(), z.unknown())),
    monthly_reports: z.array(z.record(z.string(), z.unknown())).optional().default([]),
  }),
});

/* ------------------------------------------------------------------ */
/* READ endpoints                                                      */
/* ------------------------------------------------------------------ */

function memberName(s: LedgerState, id: number | null): string | null {
  if (id === null) return null;
  return s.members.find((m) => m.id === id)?.name ?? null;
}

function getMonths(s: LedgerState) {
  const currentMonth = getCurrentMonthKey();
  return {
    currentMonth,
    months: getAvailableMonths(s, currentMonth),
    closedMonths: s.monthly_reports.filter((r) => r.is_closed === 1).map((r) => r.month_key),
  };
}

function getMembers(s: LedgerState, q: URLSearchParams) {
  const monthKey = resolveMonth(q);
  const statusFilter = q.get('status') || 'all';
  const search = (q.get('search') || '').trim().toLowerCase();
  const summary = computeMonthlySummary(s, monthKey);
  const summaryMap = new Map(summary.members.map((m) => [m.memberId, m]));

  const all = [...s.members].sort((a, b) => b.is_active - a.is_active || cmpNoCase(a.name, b.name));
  let list = all.map((m) => {
    const st = summaryMap.get(m.id);
    return {
      id: m.id,
      name: m.name,
      phone: m.phone,
      photoUrl: m.photo_url,
      joinDate: m.join_date,
      isActive: m.is_active === 1,
      notes: m.notes,
      totalDeposit: st?.totalDeposit ?? 0,
      breakfastCount: st?.breakfastCount ?? 0,
      lunchCount: st?.lunchCount ?? 0,
      dinnerCount: st?.dinnerCount ?? 0,
      extraMealCount: st?.extraMealCount ?? 0,
      totalMeals: st?.totalMeals ?? 0,
      mealCost: st?.mealCost ?? 0,
      individualExpense: st?.individualExpense ?? 0,
      totalExpense: st?.totalExpense ?? 0,
      balance: st?.balance ?? 0,
    };
  });
  if (statusFilter === 'active') list = list.filter((m) => m.isActive);
  else if (statusFilter === 'inactive') list = list.filter((m) => !m.isActive);
  if (search) {
    list = list.filter((m) => m.name.toLowerCase().includes(search) || m.phone.toLowerCase().includes(search));
  }
  return { monthKey, mealRate: summary.totals.mealRate, members: list };
}

function getMemberDetail(s: LedgerState, idRaw: string, q: URLSearchParams) {
  const memberId = Number(idRaw);
  if (!Number.isInteger(memberId) || memberId <= 0) bad('Invalid member ID');
  const monthKey = resolveMonth(q);
  const member = s.members.find((m) => m.id === memberId);
  if (!member) notFound('Member not found');

  const summary = computeMonthlySummary(s, monthKey);
  const stat = summary.members.find((m) => m.memberId === memberId);

  const deposits = s.deposits
    .filter((r) => r.member_id === memberId && r.month_key === monthKey)
    .sort((a, b) => cmpStr(b.deposit_date, a.deposit_date) || b.id - a.id)
    .map((r) => ({
      id: r.id,
      deposit_date: r.deposit_date,
      amount: r.amount,
      payment_method: r.payment_method,
      note: r.note,
      created_at: r.created_at,
    }));
  const expenses = s.individual_expenses
    .filter((r) => r.member_id === memberId && r.month_key === monthKey && r.expense_type === 'individual')
    .sort((a, b) => cmpStr(b.expense_date, a.expense_date) || b.id - a.id)
    .map((r) => ({
      id: r.id,
      expense_date: r.expense_date,
      title: r.title,
      amount: r.amount,
      notes: r.notes,
      created_at: r.created_at,
    }));
  const meals = s.meals
    .filter((r) => r.member_id === memberId && r.month_key === monthKey)
    .sort((a, b) => cmpStr(b.meal_date, a.meal_date))
    .map((r) => ({
      id: r.id,
      meal_date: r.meal_date,
      breakfast: r.breakfast,
      lunch: r.lunch,
      dinner: r.dinner,
      extra_meal: r.extra_meal,
      total_meal: r.total_meal,
      note: r.note,
    }));

  const base = {
    memberId: member.id,
    name: member.name,
    phone: member.phone,
    photoUrl: member.photo_url,
    joinDate: member.join_date,
    isActive: member.is_active === 1,
    notes: member.notes,
  };
  return {
    monthKey,
    mealRate: summary.totals.mealRate,
    member: {
      id: member.id,
      name: member.name,
      phone: member.phone,
      photoUrl: member.photo_url,
      joinDate: member.join_date,
      isActive: member.is_active === 1,
      notes: member.notes,
    },
    stats: stat ?? {
      ...base,
      totalDeposit: 0,
      breakfastCount: 0,
      lunchCount: 0,
      dinnerCount: 0,
      extraMealCount: 0,
      totalMeals: 0,
      mealCost: 0,
      individualExpense: 0,
      totalExpense: 0,
      balance: 0,
    },
    deposits,
    expenses,
    meals,
  };
}

function getMeals(s: LedgerState, q: URLSearchParams) {
  const monthKey = resolveMonth(q);
  const dateParam = q.get('date');
  const dateFilter = dateParam && dateRegex.test(dateParam) ? dateParam : null;
  const memberIdFilter = q.get('memberId') ? Number(q.get('memberId')) : null;

  const members = [...s.members].sort((a, b) => b.is_active - a.is_active || cmpNoCase(a.name, b.name));
  const byId = new Map(s.members.map((m) => [m.id, m]));

  let rows = s.meals.filter((r) => r.month_key === monthKey && byId.has(r.member_id));
  if (dateFilter) rows = rows.filter((r) => r.meal_date === dateFilter);
  if (memberIdFilter && Number.isInteger(memberIdFilter)) rows = rows.filter((r) => r.member_id === memberIdFilter);
  rows.sort(
    (a, b) =>
      cmpStr(b.meal_date, a.meal_date) ||
      cmpNoCase((byId.get(a.member_id) as MemberRow).name, (byId.get(b.member_id) as MemberRow).name)
  );
  const entries = rows.map((r) => {
    const mb = byId.get(r.member_id) as MemberRow;
    return {
      id: r.id,
      member_id: r.member_id,
      member_name: mb.name,
      member_active: mb.is_active,
      meal_date: r.meal_date,
      month_key: r.month_key,
      breakfast: r.breakfast,
      lunch: r.lunch,
      dinner: r.dinner,
      extra_meal: r.extra_meal,
      total_meal: r.total_meal,
      note: r.note,
      created_at: r.created_at,
      updated_at: r.updated_at,
    };
  });

  let dailySheet: Array<Record<string, unknown>> = [];
  if (dateFilter) {
    const existing = new Map(s.meals.filter((r) => r.meal_date === dateFilter).map((r) => [r.member_id, r]));
    dailySheet = members
      .filter((m) => m.is_active === 1 || existing.has(m.id))
      .map((m) => {
        const ex = existing.get(m.id);
        return {
          memberId: m.id,
          memberName: m.name,
          isActive: m.is_active === 1,
          breakfast: ex?.breakfast ?? 0,
          lunch: ex?.lunch ?? 0,
          dinner: ex?.dinner ?? 0,
          extraMeal: ex?.extra_meal ?? 0,
          totalMeal: ex?.total_meal ?? 0,
          note: ex?.note ?? '',
          hasEntry: Boolean(ex),
        };
      });
  }
  return {
    monthKey,
    date: dateFilter,
    enableBreakfast: s.settings.enable_breakfast === 'true',
    entries,
    dailySheet,
  };
}

function getBazar(s: LedgerState, q: URLSearchParams) {
  const monthKey = resolveMonth(q);
  const dateParam = q.get('date');
  const dateFilter = dateParam && dateRegex.test(dateParam) ? dateParam : null;
  const search = (q.get('search') || '').trim().toLowerCase();

  let rows = s.bazar_transactions.filter((r) => r.month_key === monthKey);
  if (dateFilter) rows = rows.filter((r) => r.bazar_date === dateFilter);
  rows.sort((a, b) => cmpStr(b.bazar_date, a.bazar_date) || b.id - a.id);

  let enriched = rows.map((t) => ({
    id: t.id,
    bazarDate: t.bazar_date,
    monthKey: t.month_key,
    title: t.title,
    shopperMemberId: t.shopper_member_id,
    shopperName: memberName(s, t.shopper_member_id) || t.shopper_name,
    totalAmount: t.total_amount,
    notes: t.notes,
    createdAt: t.created_at,
    updatedAt: t.updated_at,
    items: s.bazar_items
      .filter((it) => it.transaction_id === t.id)
      .sort((a, b) => a.id - b.id)
      .map((it) => ({ ...it })),
  }));
  if (search) {
    enriched = enriched.filter(
      (tx) =>
        tx.title.toLowerCase().includes(search) ||
        tx.shopperName.toLowerCase().includes(search) ||
        tx.items.some((it) => String(it.item_name || '').toLowerCase().includes(search))
    );
  }
  return {
    monthKey,
    totalBazarExpense: roundMoney(sum(enriched, (t) => t.totalAmount)),
    transactions: enriched,
  };
}

function getExpenses(s: LedgerState, q: URLSearchParams) {
  const monthKey = resolveMonth(q);
  const t = q.get('type');
  const expenseType = t === 'individual' || t === 'common' ? t : null;
  const memberIdFilter = q.get('memberId') ? Number(q.get('memberId')) : null;
  const search = (q.get('search') || '').trim().toLowerCase();

  let rows = s.individual_expenses.filter((r) => r.month_key === monthKey);
  if (expenseType) rows = rows.filter((r) => r.expense_type === expenseType);
  if (memberIdFilter && Number.isInteger(memberIdFilter)) rows = rows.filter((r) => r.member_id === memberIdFilter);
  rows.sort((a, b) => cmpStr(b.expense_date, a.expense_date) || b.id - a.id);

  let withNames = rows.map((r) => ({ r, name: memberName(s, r.member_id) }));
  if (search) {
    withNames = withNames.filter(
      ({ r, name }) => r.title.toLowerCase().includes(search) || (name ?? '').toLowerCase().includes(search)
    );
  }
  const individualTotal = sum(withNames.filter(({ r }) => r.expense_type === 'individual'), ({ r }) => r.amount);
  const commonTotal = sum(withNames.filter(({ r }) => r.expense_type === 'common'), ({ r }) => r.amount);
  return {
    monthKey,
    individualTotal: roundMoney(individualTotal),
    commonTotal: roundMoney(commonTotal),
    expenses: withNames.map(({ r, name }) => ({
      id: r.id,
      expenseDate: r.expense_date,
      monthKey: r.month_key,
      expenseType: r.expense_type,
      memberId: r.member_id,
      memberName: name ?? '',
      title: r.title,
      amount: r.amount,
      notes: r.notes,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    })),
  };
}

function getDeposits(s: LedgerState, q: URLSearchParams) {
  const monthKey = resolveMonth(q);
  const memberIdFilter = q.get('memberId') ? Number(q.get('memberId')) : null;
  const search = (q.get('search') || '').trim().toLowerCase();
  const summary = computeMonthlySummary(s, monthKey);
  const summaryMap = new Map(summary.members.map((m) => [m.memberId, m]));
  const byId = new Map(s.members.map((m) => [m.id, m]));

  let rows = s.deposits.filter((r) => r.month_key === monthKey && byId.has(r.member_id));
  if (memberIdFilter && Number.isInteger(memberIdFilter)) rows = rows.filter((r) => r.member_id === memberIdFilter);
  rows.sort((a, b) => cmpStr(a.deposit_date, b.deposit_date) || a.id - b.id);

  const running = new Map<number, number>();
  let computed = rows.map((r) => {
    const prev = running.get(r.member_id) ?? 0;
    const after = prev + r.amount;
    running.set(r.member_id, after);
    return {
      id: r.id,
      memberId: r.member_id,
      memberName: (byId.get(r.member_id) as MemberRow).name,
      depositDate: r.deposit_date,
      monthKey: r.month_key,
      amount: r.amount,
      previousDeposit: roundMoney(prev),
      cumulativeDeposit: roundMoney(after),
      currentBalance: summaryMap.get(r.member_id)?.balance ?? 0,
      paymentMethod: r.payment_method,
      note: r.note,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  });
  computed = computed.reverse();
  if (search) {
    computed = computed.filter(
      (d) =>
        d.memberName.toLowerCase().includes(search) ||
        d.paymentMethod.toLowerCase().includes(search) ||
        d.note.toLowerCase().includes(search)
    );
  }
  return { monthKey, totalDeposit: summary.totals.totalDeposit, deposits: computed };
}

function getReports(s: LedgerState, q: URLSearchParams) {
  const monthKey = resolveMonth(q);
  const summary = computeMonthlySummary(s, monthKey);
  const savedReports = [...s.monthly_reports]
    .sort((a, b) => cmpStr(b.month_key, a.month_key))
    .map((r) => ({
      month_key: r.month_key,
      is_closed: r.is_closed,
      closed_at: r.closed_at,
      closed_by: r.closed_by,
      total_members: r.total_members,
      total_deposit: r.total_deposit,
      total_bazar_expense: r.total_bazar_expense,
      total_common_extra_expense: r.total_common_extra_expense,
      total_individual_expense: r.total_individual_expense,
      total_meals: r.total_meals,
      meal_rate: r.meal_rate,
      total_expense: r.total_expense,
      remaining_balance: r.remaining_balance,
    }));
  return { summary, savedReports };
}

/* ------------------------------------------------------------------ */
/* WRITE endpoints                                                     */
/* ------------------------------------------------------------------ */

function now(): string {
  return nowSql();
}

function createMember(body: unknown) {
  const d = parseBody(memberSchema, body, 'Invalid member data');
  return transaction((s) => {
    const row: MemberRow = {
      id: nextId('members'),
      name: d.name,
      phone: d.phone,
      photo_url: d.photoUrl,
      join_date: d.joinDate,
      is_active: d.isActive ? 1 : 0,
      notes: d.notes,
      created_at: now(),
      updated_at: now(),
    };
    s.members.push(row);
    audit(s, 'CREATE', 'member', `Added member '${d.name}'`, row.id);
    return { id: row.id, ok: true };
  });
}

function updateMember(idRaw: string, body: unknown) {
  const id = parseId(idRaw, 'member');
  const d = parseBody(memberSchema, body, 'Invalid member data');
  return transaction((s) => {
    const m = s.members.find((x) => x.id === id);
    if (!m) notFound('Member not found');
    m.name = d.name;
    m.phone = d.phone;
    m.photo_url = d.photoUrl;
    m.join_date = d.joinDate;
    m.is_active = d.isActive ? 1 : 0;
    m.notes = d.notes;
    m.updated_at = now();
    audit(s, 'UPDATE', 'member', `Updated member '${d.name}'`, id);
    return { ok: true };
  });
}

function setMemberStatus(idRaw: string, body: unknown) {
  const id = Number(idRaw);
  const parsed = z.object({ isActive: z.boolean() }).safeParse(body);
  if (!Number.isInteger(id) || id <= 0 || !parsed.success) bad('Invalid request');
  return transaction((s) => {
    const m = s.members.find((x) => x.id === id);
    if (!m) notFound('Member not found');
    m.is_active = parsed.data.isActive ? 1 : 0;
    m.updated_at = now();
    audit(
      s,
      'UPDATE',
      'member_status',
      `${parsed.data.isActive ? 'Activated' : 'Deactivated'} member '${m.name}'`,
      id
    );
    return { ok: true };
  });
}

function deleteMember(idRaw: string) {
  const id = parseId(idRaw, 'member');
  return transaction((s) => {
    const m = s.members.find((x) => x.id === id);
    if (!m) notFound('Member not found');
    // ON DELETE CASCADE / SET NULL, exactly like the old schema
    s.meals = s.meals.filter((r) => r.member_id !== id);
    s.deposits = s.deposits.filter((r) => r.member_id !== id);
    s.individual_expenses = s.individual_expenses.filter((r) => r.member_id !== id);
    for (const b of s.bazar_transactions) if (b.shopper_member_id === id) b.shopper_member_id = null;
    s.members = s.members.filter((x) => x.id !== id);
    audit(s, 'DELETE', 'member', `Removed member '${m.name}' and associated records`, id);
    return { ok: true };
  });
}

function saveMealsBulk(body: unknown) {
  const { mealDate, entries } = parseBody(bulkMealsSchema, body, 'Invalid meal data');
  const monthKey = monthKeyFromDate(mealDate);
  return transaction((s) => {
    assertMonthOpen(s, monthKey);
    let saved = 0;
    for (const e of entries) {
      if (!s.members.some((m) => m.id === e.memberId)) notFound('Selected member not found');
      const total = Math.round((e.breakfast + e.lunch + e.dinner + e.extraMeal) * 100) / 100;
      saved += total;
      const existing = s.meals.find((r) => r.member_id === e.memberId && r.meal_date === mealDate);
      if (existing) {
        existing.breakfast = e.breakfast;
        existing.lunch = e.lunch;
        existing.dinner = e.dinner;
        existing.extra_meal = e.extraMeal;
        existing.total_meal = total;
        existing.note = e.note;
        existing.updated_at = now();
      } else {
        const row: MealRow = {
          id: nextId('meals'),
          member_id: e.memberId,
          meal_date: mealDate,
          month_key: monthKey,
          breakfast: e.breakfast,
          lunch: e.lunch,
          dinner: e.dinner,
          extra_meal: e.extraMeal,
          total_meal: total,
          note: e.note,
          created_at: now(),
          updated_at: now(),
        };
        s.meals.push(row);
      }
    }
    audit(
      s,
      'UPDATE',
      'meals_bulk',
      `Saved daily meal sheet for ${mealDate} (${entries.length} members, ${saved} meals)`,
      mealDate
    );
    return { ok: true };
  });
}

function deleteMeal(idRaw: string) {
  const id = parseId(idRaw, 'meal');
  return transaction((s) => {
    const m = s.meals.find((x) => x.id === id);
    if (!m) notFound('Meal entry not found');
    assertMonthOpen(s, m.month_key);
    s.meals = s.meals.filter((x) => x.id !== id);
    audit(s, 'DELETE', 'meal', `Deleted meal record for ${m.meal_date}`, id);
    return { ok: true };
  });
}

type BazarInput = z.infer<typeof bazarTxSchema>;

function itemRows(txId: number, items: BazarInput['items']): BazarItemRow[] {
  return items.map((item) => {
    const unitPrice =
      item.unitPrice !== undefined && item.unitPrice >= 0
        ? item.unitPrice
        : item.quantity > 0
          ? Math.round((item.totalPrice / item.quantity + Number.EPSILON) * 100) / 100
          : 0;
    return {
      id: nextId('bazar_items'),
      transaction_id: txId,
      item_name: item.itemName,
      quantity: item.quantity,
      unit: item.unit,
      unit_price: unitPrice,
      total_price: Math.round((item.totalPrice + Number.EPSILON) * 100) / 100,
      created_at: now(),
      updated_at: now(),
    };
  });
}

function createBazar(body: unknown) {
  const d = parseBody(bazarTxSchema, body, 'Invalid bazar payload');
  const monthKey = monthKeyFromDate(d.bazarDate);
  return transaction((s) => {
    assertMonthOpen(s, monthKey);
    let shopper = d.shopperName;
    if (d.shopperMemberId) shopper = memberName(s, d.shopperMemberId) ?? shopper;
    const grand = Math.round((d.items.reduce((a, it) => a + it.totalPrice, 0) + Number.EPSILON) * 100) / 100;
    const row: BazarRow = {
      id: nextId('bazar_transactions'),
      bazar_date: d.bazarDate,
      month_key: monthKey,
      title: d.title,
      shopper_member_id: d.shopperMemberId && memberName(s, d.shopperMemberId) ? d.shopperMemberId : null,
      shopper_name: shopper,
      total_amount: grand,
      notes: d.notes,
      created_at: now(),
      updated_at: now(),
    };
    s.bazar_transactions.push(row);
    s.bazar_items.push(...itemRows(row.id, d.items));
    audit(s, 'CREATE', 'bazar', `Added bazar '${d.title}' on ${d.bazarDate} (Total: ${grand})`, row.id);
    return { id: row.id, totalAmount: grand, ok: true };
  });
}

function updateBazar(idRaw: string, body: unknown) {
  const id = parseId(idRaw, 'bazar');
  const d = parseBody(bazarTxSchema, body, 'Invalid bazar payload');
  const newMonth = monthKeyFromDate(d.bazarDate);
  return transaction((s) => {
    const tx = s.bazar_transactions.find((x) => x.id === id);
    if (!tx) notFound('Bazar transaction not found');
    assertMonthOpen(s, tx.month_key);
    assertMonthOpen(s, newMonth);
    let shopper = d.shopperName;
    if (d.shopperMemberId) shopper = memberName(s, d.shopperMemberId) ?? shopper;
    const grand = Math.round((d.items.reduce((a, it) => a + it.totalPrice, 0) + Number.EPSILON) * 100) / 100;
    tx.bazar_date = d.bazarDate;
    tx.month_key = newMonth;
    tx.title = d.title;
    tx.shopper_member_id = d.shopperMemberId && memberName(s, d.shopperMemberId) ? d.shopperMemberId : null;
    tx.shopper_name = shopper;
    tx.total_amount = grand;
    tx.notes = d.notes;
    tx.updated_at = now();
    s.bazar_items = s.bazar_items.filter((it) => it.transaction_id !== id);
    s.bazar_items.push(...itemRows(id, d.items));
    audit(s, 'UPDATE', 'bazar', `Updated bazar '${d.title}' on ${d.bazarDate} (Total: ${grand})`, id);
    return { ok: true, totalAmount: grand };
  });
}

function deleteBazar(idRaw: string) {
  const id = parseId(idRaw, 'bazar');
  return transaction((s) => {
    const tx = s.bazar_transactions.find((x) => x.id === id);
    if (!tx) notFound('Bazar transaction not found');
    assertMonthOpen(s, tx.month_key);
    s.bazar_items = s.bazar_items.filter((it) => it.transaction_id !== id);
    s.bazar_transactions = s.bazar_transactions.filter((x) => x.id !== id);
    audit(s, 'DELETE', 'bazar', `Deleted bazar '${tx.title}' (Amount: ${tx.total_amount})`, id);
    return { ok: true };
  });
}

function createExpense(body: unknown) {
  const d = parseBody(expenseSchema, body, 'Invalid expense data');
  const monthKey = monthKeyFromDate(d.expenseDate);
  return transaction((s) => {
    assertMonthOpen(s, monthKey);
    const memberId = d.expenseType === 'individual' ? d.memberId ?? null : null;
    if (memberId !== null && !s.members.some((m) => m.id === memberId)) notFound('Selected member not found');
    const amt = Math.round((d.amount + Number.EPSILON) * 100) / 100;
    const row: ExpenseRow = {
      id: nextId('individual_expenses'),
      expense_date: d.expenseDate,
      month_key: monthKey,
      expense_type: d.expenseType,
      member_id: memberId,
      title: d.title,
      amount: amt,
      notes: d.notes,
      created_at: now(),
      updated_at: now(),
    };
    s.individual_expenses.push(row);
    audit(s, 'CREATE', 'expense', `Added ${d.expenseType} expense '${d.title}' (${amt})`, row.id);
    return { id: row.id, ok: true };
  });
}

function updateExpense(idRaw: string, body: unknown) {
  const id = parseId(idRaw, 'expense');
  const d = parseBody(expenseSchema, body, 'Invalid expense data');
  const newMonth = monthKeyFromDate(d.expenseDate);
  return transaction((s) => {
    const row = s.individual_expenses.find((x) => x.id === id);
    if (!row) notFound('Expense not found');
    assertMonthOpen(s, row.month_key);
    assertMonthOpen(s, newMonth);
    const memberId = d.expenseType === 'individual' ? d.memberId ?? null : null;
    if (memberId !== null && !s.members.some((m) => m.id === memberId)) notFound('Selected member not found');
    const amt = Math.round((d.amount + Number.EPSILON) * 100) / 100;
    row.expense_date = d.expenseDate;
    row.month_key = newMonth;
    row.expense_type = d.expenseType;
    row.member_id = memberId;
    row.title = d.title;
    row.amount = amt;
    row.notes = d.notes;
    row.updated_at = now();
    audit(s, 'UPDATE', 'expense', `Updated ${d.expenseType} expense '${d.title}' (${amt})`, id);
    return { ok: true };
  });
}

function deleteExpense(idRaw: string) {
  const id = parseId(idRaw, 'expense');
  return transaction((s) => {
    const row = s.individual_expenses.find((x) => x.id === id);
    if (!row) notFound('Expense not found');
    assertMonthOpen(s, row.month_key);
    s.individual_expenses = s.individual_expenses.filter((x) => x.id !== id);
    audit(s, 'DELETE', 'expense', `Deleted expense '${row.title}' (${row.amount})`, id);
    return { ok: true };
  });
}

function createDeposit(body: unknown) {
  const d = parseBody(depositSchema, body, 'Invalid deposit data');
  const monthKey = monthKeyFromDate(d.depositDate);
  return transaction((s) => {
    assertMonthOpen(s, monthKey);
    const member = s.members.find((m) => m.id === d.memberId);
    if (!member) notFound('Selected member not found');
    const amt = Math.round((d.amount + Number.EPSILON) * 100) / 100;
    const row: DepositRow = {
      id: nextId('deposits'),
      member_id: d.memberId,
      deposit_date: d.depositDate,
      month_key: monthKey,
      amount: amt,
      payment_method: d.paymentMethod,
      note: d.note,
      created_at: now(),
      updated_at: now(),
    };
    s.deposits.push(row);
    audit(s, 'CREATE', 'deposit', `Recorded deposit of ${amt} for '${member.name}' via ${d.paymentMethod}`, row.id);
    return { id: row.id, ok: true };
  });
}

function updateDeposit(idRaw: string, body: unknown) {
  const id = parseId(idRaw, 'deposit');
  const d = parseBody(depositSchema, body, 'Invalid deposit data');
  const newMonth = monthKeyFromDate(d.depositDate);
  return transaction((s) => {
    const row = s.deposits.find((x) => x.id === id);
    if (!row) notFound('Deposit record not found');
    assertMonthOpen(s, row.month_key);
    assertMonthOpen(s, newMonth);
    if (!s.members.some((m) => m.id === d.memberId)) notFound('Selected member not found');
    const amt = Math.round((d.amount + Number.EPSILON) * 100) / 100;
    row.member_id = d.memberId;
    row.deposit_date = d.depositDate;
    row.month_key = newMonth;
    row.amount = amt;
    row.payment_method = d.paymentMethod;
    row.note = d.note;
    row.updated_at = now();
    audit(s, 'UPDATE', 'deposit', `Updated deposit #${id} to ${amt}`, id);
    return { ok: true };
  });
}

function deleteDeposit(idRaw: string) {
  const id = parseId(idRaw, 'deposit');
  return transaction((s) => {
    const row = s.deposits.find((x) => x.id === id);
    if (!row) notFound('Deposit not found');
    assertMonthOpen(s, row.month_key);
    s.deposits = s.deposits.filter((x) => x.id !== id);
    audit(s, 'DELETE', 'deposit', `Deleted deposit #${id} (Amount: ${row.amount})`, id);
    return { ok: true };
  });
}

function closeMonth(body: unknown) {
  const parsed = z.object({ monthKey: z.string().regex(monthRegex) }).safeParse(body);
  if (!parsed.success) bad('Valid monthKey (YYYY-MM) is required');
  const { monthKey } = parsed.data;
  return transaction((s) => {
    const existing = s.monthly_reports.find((r) => r.month_key === monthKey);
    if (existing?.is_closed === 1) throw new ApiError(409, `Month ${monthKey} is already closed.`);
    const summary = computeMonthlySummary(s, monthKey);
    const t = summary.totals;
    const fields = {
      is_closed: 1,
      closed_at: now(),
      closed_by: ACTOR,
      total_members: t.memberCount,
      total_deposit: t.totalDeposit,
      total_bazar_expense: t.bazarExpense,
      total_common_extra_expense: t.commonExtraExpense,
      total_individual_expense: t.totalIndividualExpense,
      total_meals: t.totalMeals,
      meal_rate: t.mealRate,
      total_expense: t.totalMessExpense,
      remaining_balance: t.remainingBalance,
      snapshot_json: JSON.stringify({ members: summary.members }),
      updated_at: now(),
    };
    if (existing) Object.assign(existing, fields);
    else {
      const row: ReportRow = { id: nextId('monthly_reports'), month_key: monthKey, created_at: now(), ...fields };
      s.monthly_reports.push(row);
    }
    audit(
      s,
      'CLOSE_MONTH',
      'monthly_report',
      `Closed month ${monthKey} (Meal Rate: ${t.mealRate}, Remaining: ${t.remainingBalance})`,
      monthKey
    );
    return { ok: true };
  });
}

function reopenMonth(body: unknown) {
  const parsed = z.object({ monthKey: z.string().regex(monthRegex) }).safeParse(body);
  if (!parsed.success) bad('Valid monthKey (YYYY-MM) is required');
  const { monthKey } = parsed.data;
  return transaction((s) => {
    const r = s.monthly_reports.find((x) => x.month_key === monthKey);
    if (r) {
      r.is_closed = 0;
      r.updated_at = now();
    }
    audit(s, 'REOPEN_MONTH', 'monthly_report', `Reopened month ${monthKey} for adjustments`, monthKey);
    return { ok: true };
  });
}

function saveSettings(body: unknown) {
  const d = parseBody(settingsSchema, body, 'Invalid settings data');
  return transaction((s) => {
    Object.assign(s.settings, d);
    audit(s, 'SETTINGS_UPDATE', 'settings', 'Updated mess system settings');
    return { ok: true, settings: getSettingsMap(s) };
  });
}

function auditLogs(q: URLSearchParams) {
  const limit = Math.min(Math.max(Number(q.get('limit')) || 100, 1), 500);
  const logs = [...getState().audit_logs].sort((a, b) => b.id - a.id).slice(0, limit);
  return { logs };
}

function backup() {
  const s = getState();
  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    exportedBy: 'device',
    tables: {
      settings: Object.entries(s.settings).map(([key, value]) => ({ key, value, updated_at: now() })),
      members: [...s.members].sort((a, b) => a.id - b.id),
      meals: [...s.meals].sort((a, b) => a.id - b.id),
      bazar_transactions: [...s.bazar_transactions].sort((a, b) => a.id - b.id),
      bazar_items: [...s.bazar_items].sort((a, b) => a.id - b.id),
      individual_expenses: [...s.individual_expenses].sort((a, b) => a.id - b.id),
      deposits: [...s.deposits].sort((a, b) => a.id - b.id),
      monthly_reports: [...s.monthly_reports].sort((a, b) => a.id - b.id),
    },
  };
}

const num = (v: unknown, d = 0) => (v === null || v === undefined || v === '' ? d : Number(v));
const str = (v: unknown, d = '') => (v === null || v === undefined ? d : String(v));
const optStr = (v: unknown) => (v ? String(v) : null);

function restoreBackup(body: unknown) {
  const parsed = restoreSchema.safeParse(body);
  if (!parsed.success) bad('Invalid backup file structure');
  const t = parsed.data.tables;
  const fail = (): never => bad('Backup restore failed due to invalid or conflicting data');

  // Build the new state completely first; only swap it in if everything is consistent.
  const next = emptyState();
  const ids = <T extends { id: number }>(rows: T[]) => {
    const seen = new Set<number>();
    for (const r of rows) {
      if (!Number.isInteger(r.id) || r.id <= 0 || seen.has(r.id)) fail();
      seen.add(r.id);
    }
    return seen;
  };
  const nonNeg = (...vals: number[]) => {
    for (const v of vals) if (!Number.isFinite(v) || v < 0) fail();
  };

  for (const k of Object.keys(DEFAULT_SETTINGS)) {
    const found = t.settings.find((x) => x.key === k);
    if (found) next.settings[k] = found.value;
  }
  if (!settingsSchema.safeParse({
    mess_name: next.settings.mess_name,
    mess_name_bn: next.settings.mess_name_bn,
    currency_symbol: next.settings.currency_symbol,
    enable_breakfast: next.settings.enable_breakfast,
    default_language: next.settings.default_language,
  }).success) {
    // Keep going with defaults for malformed setting values rather than rejecting a good backup.
    for (const k of ['mess_name', 'mess_name_bn', 'currency_symbol', 'enable_breakfast', 'default_language']) {
      next.settings[k] = DEFAULT_SETTINGS[k];
    }
  }

  next.members = t.members.map((m) => ({
    id: num(m.id),
    name: str(m.name),
    phone: str(m.phone),
    photo_url: isValidSafePhotoUrl(str(m.photo_url)) ? str(m.photo_url) : '',
    join_date: str(m.join_date, '2026-01-01'),
    is_active: num(m.is_active, 1) ? 1 : 0,
    notes: str(m.notes),
    created_at: str(m.created_at, now()),
    updated_at: str(m.updated_at, now()),
  }));
  const memberIds = ids(next.members);

  next.meals = t.meals.map((m) => ({
    id: num(m.id),
    member_id: num(m.member_id),
    meal_date: str(m.meal_date),
    month_key: str(m.month_key),
    breakfast: num(m.breakfast),
    lunch: num(m.lunch),
    dinner: num(m.dinner),
    extra_meal: num(m.extra_meal),
    total_meal: num(m.total_meal),
    note: str(m.note),
    created_at: str(m.created_at, now()),
    updated_at: str(m.updated_at, now()),
  }));
  ids(next.meals);
  const mealKeys = new Set<string>();
  for (const m of next.meals) {
    if (!memberIds.has(m.member_id) || !dateRegex.test(m.meal_date)) fail();
    nonNeg(m.breakfast, m.lunch, m.dinner, m.extra_meal, m.total_meal);
    const key = `${m.member_id}|${m.meal_date}`;
    if (mealKeys.has(key)) fail();
    mealKeys.add(key);
  }

  next.bazar_transactions = t.bazar_transactions.map((b) => ({
    id: num(b.id),
    bazar_date: str(b.bazar_date),
    month_key: str(b.month_key),
    title: str(b.title),
    shopper_member_id: b.shopper_member_id !== null && b.shopper_member_id !== undefined ? num(b.shopper_member_id) : null,
    shopper_name: str(b.shopper_name),
    total_amount: num(b.total_amount),
    notes: str(b.notes),
    created_at: str(b.created_at, now()),
    updated_at: str(b.updated_at, now()),
  }));
  const txIds = ids(next.bazar_transactions);
  for (const b of next.bazar_transactions) {
    nonNeg(b.total_amount);
    if (!dateRegex.test(b.bazar_date) || !b.title) fail();
    if (b.shopper_member_id !== null && !memberIds.has(b.shopper_member_id)) b.shopper_member_id = null;
  }

  next.bazar_items = t.bazar_items.map((it) => ({
    id: num(it.id),
    transaction_id: num(it.transaction_id),
    item_name: str(it.item_name),
    quantity: num(it.quantity),
    unit: str(it.unit),
    unit_price: num(it.unit_price),
    total_price: num(it.total_price),
    created_at: str(it.created_at, now()),
    updated_at: str(it.updated_at, now()),
  }));
  ids(next.bazar_items);
  for (const it of next.bazar_items) {
    if (!txIds.has(it.transaction_id) || !(it.quantity > 0)) fail();
    nonNeg(it.unit_price, it.total_price);
  }

  next.individual_expenses = t.individual_expenses.map((e) => ({
    id: num(e.id),
    expense_date: str(e.expense_date),
    month_key: str(e.month_key),
    expense_type: e.expense_type === 'common' ? 'common' : 'individual',
    member_id: e.member_id !== null && e.member_id !== undefined ? num(e.member_id) : null,
    title: str(e.title),
    amount: num(e.amount),
    notes: str(e.notes),
    created_at: str(e.created_at, now()),
    updated_at: str(e.updated_at, now()),
  }));
  ids(next.individual_expenses);
  for (const e of next.individual_expenses) {
    nonNeg(e.amount);
    if (!dateRegex.test(e.expense_date)) fail();
    if (e.member_id !== null && !memberIds.has(e.member_id)) fail();
  }

  next.deposits = t.deposits.map((d) => ({
    id: num(d.id),
    member_id: num(d.member_id),
    deposit_date: str(d.deposit_date),
    month_key: str(d.month_key),
    amount: num(d.amount),
    payment_method: str(d.payment_method, 'cash'),
    note: str(d.note),
    created_at: str(d.created_at, now()),
    updated_at: str(d.updated_at, now()),
  }));
  ids(next.deposits);
  for (const d of next.deposits) {
    if (!memberIds.has(d.member_id) || !dateRegex.test(d.deposit_date) || !(d.amount > 0)) fail();
  }

  next.monthly_reports = t.monthly_reports.map((r) => ({
    id: num(r.id),
    month_key: str(r.month_key),
    is_closed: num(r.is_closed) ? 1 : 0,
    closed_at: optStr(r.closed_at),
    closed_by: optStr(r.closed_by),
    total_members: num(r.total_members),
    total_deposit: num(r.total_deposit),
    total_bazar_expense: num(r.total_bazar_expense),
    total_common_extra_expense: num(r.total_common_extra_expense),
    total_individual_expense: num(r.total_individual_expense),
    total_meals: num(r.total_meals),
    meal_rate: num(r.meal_rate),
    total_expense: num(r.total_expense),
    remaining_balance: num(r.remaining_balance),
    snapshot_json: str(r.snapshot_json, '{}'),
    created_at: str(r.created_at, now()),
    updated_at: str(r.updated_at, now()),
  }));
  ids(next.monthly_reports);
  const months = new Set<string>();
  for (const r of next.monthly_reports) {
    if (!monthRegex.test(r.month_key) || months.has(r.month_key)) fail();
    months.add(r.month_key);
  }

  return transaction((s) => {
    const keepAudit = s.audit_logs;
    const keepAuditCounter = s.counters.audit_logs;
    replaceState(next);
    const cur = getState();
    cur.audit_logs = keepAudit;
    cur.counters.audit_logs = keepAuditCounter;
    for (const table of TABLES) {
      const maxId = (cur[table] as Array<{ id: number }>).reduce((m, r) => Math.max(m, r.id), 0);
      cur.counters[table] = Math.max(cur.counters[table], maxId);
    }
    audit(
      cur,
      'RESTORE',
      'database',
      `Restored full database backup (${cur.members.length} members, ${cur.meals.length} meals, ${cur.bazar_transactions.length} bazar records)`
    );
    return { ok: true };
  });
}

function clearData() {
  return transaction((s) => {
    s.bazar_items = [];
    s.bazar_transactions = [];
    s.meals = [];
    s.individual_expenses = [];
    s.deposits = [];
    s.monthly_reports = [];
    s.members = [];
    s.settings.demo_mode = 'false';
    audit(s, 'DEMO_CLEAR', 'database', 'Cleared operational mess data (reset to clean state)');
    return { ok: true };
  });
}

export function loadDemo(s: LedgerState): void {
  const monthKey = getCurrentMonthKey();
  s.bazar_items = [];
  s.bazar_transactions = [];
  s.meals = [];
  s.individual_expenses = [];
  s.deposits = [];
  s.monthly_reports = [];
  s.members = [];

  const addMember = (name: string, phone: string, joinDate: string, notes: string) => {
    const row: MemberRow = {
      id: nextId('members'),
      name,
      phone,
      photo_url: '',
      join_date: joinDate,
      is_active: 1,
      notes,
      created_at: now(),
      updated_at: now(),
    };
    s.members.push(row);
    return row.id;
  };
  const rahim = addMember('রহিম আহমেদ (Rahim)', '01711-000101', `${monthKey}-01`, 'Room 101');
  const karim = addMember('করিম হোসেন (Karim)', '01812-000102', `${monthKey}-01`, 'Room 102');
  const sumon = addMember('সুমন মিয়া (Sumon)', '01913-000103', `${monthKey}-01`, 'Room 103');
  const tanvir = addMember('তানভীর ইসলাম (Tanvir)', '01614-000104', `${monthKey}-02`, 'Room 104');

  const dep = (memberId: number, day: string, amount: number, method: string, note: string) => {
    s.deposits.push({
      id: nextId('deposits'),
      member_id: memberId,
      deposit_date: `${monthKey}-${day}`,
      month_key: monthKey,
      amount,
      payment_method: method,
      note,
      created_at: now(),
      updated_at: now(),
    });
  };
  dep(rahim, '01', 3500, 'cash', 'Initial monthly deposit');
  dep(karim, '01', 3000, 'bkash', 'bKash transfer');
  dep(sumon, '02', 2500, 'nagad', 'First installment');
  dep(tanvir, '02', 3200, 'cash', 'Monthly deposit');
  dep(rahim, '10', 1000, 'bkash', 'Mid-month top-up');

  const bazar = (
    day: string,
    title: string,
    shopperId: number,
    shopperName: string,
    total: number,
    notes: string,
    items: Array<[string, number, string, number, number]>
  ) => {
    const id = nextId('bazar_transactions');
    s.bazar_transactions.push({
      id,
      bazar_date: `${monthKey}-${day}`,
      month_key: monthKey,
      title,
      shopper_member_id: shopperId,
      shopper_name: shopperName,
      total_amount: total,
      notes,
      created_at: now(),
      updated_at: now(),
    });
    for (const [item_name, quantity, unit, unit_price, total_price] of items) {
      s.bazar_items.push({
        id: nextId('bazar_items'),
        transaction_id: id,
        item_name,
        quantity,
        unit,
        unit_price,
        total_price,
        created_at: now(),
        updated_at: now(),
      });
    }
  };
  bazar('01', 'সাপ্তাহিক প্রধান বাজার', rahim, 'রহিম আহমেদ (Rahim)', 1620, 'চাল, আলু, ডিম, তেল', [
    ['মিনিকেট চাল', 10, 'কেজি', 70, 700],
    ['আলু', 5, 'কেজি', 40, 200],
    ['ফার্মের ডিম', 30, 'পিস', 12, 360],
    ['সয়াবিন তেল', 2, 'লিটার', 180, 360],
  ]);
  bazar('03', 'মাছ ও সবজি বাজার', karim, 'করিম হোসেন (Karim)', 1350, 'রুই মাছ ও কাঁচাবাজার', [
    ['রুই মাছ', 2.5, 'কেজি', 360, 900],
    ['পেঁয়াজ ও কাঁচামরিচ', 3, 'কেজি', 150, 450],
  ]);
  bazar('06', 'মুরগি ও মসলা বাজার', tanvir, 'তানভীর ইসলাম (Tanvir)', 1480, 'ব্রয়লার মুরগি ও ডাল', [
    ['ব্রয়লার মুরগি', 4, 'কেজি', 210, 840],
    ['মসুর ডাল', 3, 'কেজি', 140, 420],
    ['আদা-রসুন-হলুদ', 1, 'প্যাকেট', 220, 220],
  ]);

  const days: Array<{ day: string; data: Array<[number, number, number, number, number]> }> = [
    { day: '01', data: [[rahim, 0, 1, 1, 0], [karim, 0, 1, 0, 0], [sumon, 0, 0, 0, 0], [tanvir, 0, 1, 1, 0]] },
    { day: '02', data: [[rahim, 0, 1, 1, 0], [karim, 0, 1, 1, 0], [sumon, 0, 1, 1, 0], [tanvir, 0, 1, 1, 0]] },
    { day: '03', data: [[rahim, 0, 1, 1, 1], [karim, 0, 1, 1, 0], [sumon, 0, 1, 0, 0], [tanvir, 0, 1, 1, 0]] },
    { day: '04', data: [[rahim, 0, 1, 1, 0], [karim, 0, 1, 1, 0], [sumon, 0, 1, 1, 0], [tanvir, 0, 0, 1, 0]] },
    { day: '05', data: [[rahim, 0, 1, 1, 0], [karim, 0, 1, 1, 0], [sumon, 0, 1, 1, 0], [tanvir, 0, 1, 1, 0]] },
    { day: '06', data: [[rahim, 0, 1, 1, 0], [karim, 0, 1, 1, 0], [sumon, 0, 1, 1, 0], [tanvir, 0, 1, 1, 1]] },
  ];
  for (const d of days) {
    for (const [memberId, b, l, din, ex] of d.data) {
      s.meals.push({
        id: nextId('meals'),
        member_id: memberId,
        meal_date: `${monthKey}-${d.day}`,
        month_key: monthKey,
        breakfast: b,
        lunch: l,
        dinner: din,
        extra_meal: ex,
        total_meal: b + l + din + ex,
        note: '',
        created_at: now(),
        updated_at: now(),
      });
    }
  }

  const exp = (
    day: string,
    type: 'individual' | 'common',
    memberId: number | null,
    title: string,
    amount: number,
    notes: string
  ) => {
    s.individual_expenses.push({
      id: nextId('individual_expenses'),
      expense_date: `${monthKey}-${day}`,
      month_key: monthKey,
      expense_type: type,
      member_id: memberId,
      title,
      amount,
      notes,
      created_at: now(),
      updated_at: now(),
    });
  };
  exp('03', 'individual', rahim, 'অতিরিক্ত খাবার / দই', 50, 'Personal extra');
  exp('04', 'individual', karim, 'ব্যক্তিগত বাজার', 100, 'Personal item');
  exp('05', 'individual', sumon, 'বিকালের নাস্তা', 30, 'Tea & snacks');
  exp('02', 'common', null, 'সিলিন্ডার গ্যাস রিফিল', 1200, 'Shared mess gas cylinder');

  s.settings.demo_mode = 'true';
}

/* ------------------------------------------------------------------ */
/* router                                                              */
/* ------------------------------------------------------------------ */

export function handleRequest(method: string, rawPath: string, body?: unknown): unknown {
  const [pathname, queryString = ''] = rawPath.split('?');
  const q = new URLSearchParams(queryString);
  const s = getState();
  const seg = pathname.replace(/^\/+|\/+$/g, '').split('/'); // ['api','public','members','3']
  const m = method.toUpperCase();

  if (seg[0] !== 'api') notFound('API endpoint not found');

  if (seg[1] === 'info' && m === 'GET') {
    return {
      code: 'LOCAL',
      name: s.settings.mess_name,
      nameBn: s.settings.mess_name_bn,
      isPublic: false,
      role: 'admin',
    };
  }

  if (seg[1] === 'public' && m === 'GET') {
    switch (seg[2]) {
      case 'months':
        return getMonths(s);
      case 'overview':
        return computeMonthlySummary(s, resolveMonth(q));
      case 'members':
        return seg[3] ? getMemberDetail(s, seg[3], q) : getMembers(s, q);
      case 'meals':
        return getMeals(s, q);
      case 'bazar':
        return getBazar(s, q);
      case 'expenses':
        return getExpenses(s, q);
      case 'deposits':
        return getDeposits(s, q);
      case 'reports':
        return getReports(s, q);
    }
    notFound('API endpoint not found');
  }

  if (seg[1] === 'admin') {
    const [, , res, id, sub] = seg;
    if (res === 'members') {
      if (m === 'POST' && !id) return createMember(body);
      if (m === 'PUT' && id && !sub) return updateMember(id, body);
      if (m === 'PATCH' && id && sub === 'status') return setMemberStatus(id, body);
      if (m === 'DELETE' && id && !sub) return deleteMember(id);
    }
    if (res === 'meals') {
      if (m === 'POST' && id === 'bulk') return saveMealsBulk(body);
      if (m === 'DELETE' && id && id !== 'bulk') return deleteMeal(id);
    }
    if (res === 'bazar') {
      if (m === 'POST' && !id) return createBazar(body);
      if (m === 'PUT' && id) return updateBazar(id, body);
      if (m === 'DELETE' && id) return deleteBazar(id);
    }
    if (res === 'expenses') {
      if (m === 'POST' && !id) return createExpense(body);
      if (m === 'PUT' && id) return updateExpense(id, body);
      if (m === 'DELETE' && id) return deleteExpense(id);
    }
    if (res === 'deposits') {
      if (m === 'POST' && !id) return createDeposit(body);
      if (m === 'PUT' && id) return updateDeposit(id, body);
      if (m === 'DELETE' && id) return deleteDeposit(id);
    }
    if (res === 'reports' && m === 'POST') {
      if (id === 'close') return closeMonth(body);
      if (id === 'reopen') return reopenMonth(body);
    }
    if (res === 'settings' && m === 'PUT') return saveSettings(body);
    if (res === 'audit-logs' && m === 'GET') return auditLogs(q);
    if (res === 'demo' && m === 'POST') {
      if (id === 'load') {
        return transaction((st) => {
          loadDemo(st);
          audit(st, 'DEMO_LOAD', 'database', 'Loaded sample demo dataset into database');
          return { ok: true };
        });
      }
      if (id === 'clear') return clearData();
    }
    if (res === 'backup' && m === 'GET') return backup();
    if (res === 'restore' && m === 'POST') return restoreBackup(body);
  }

  notFound('API endpoint not found');
}
