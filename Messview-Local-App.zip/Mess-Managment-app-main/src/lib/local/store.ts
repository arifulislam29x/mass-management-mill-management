/**
 * On-device database.
 *
 * All mess data lives ONLY in this phone/browser (IndexedDB, with a localStorage fallback).
 * Nothing is ever sent to a server, so nobody else can see it — only the person holding this
 * device. The state is a plain object (tables as arrays, snake_case rows like the old SQL
 * schema) that is saved as one JSON document after every change.
 *
 * Safety nets:
 *  - every change runs in a transaction: if it throws, the in-memory state is rolled back;
 *  - `state.prev` keeps the previous saved copy, `snap:YYYY-MM-DD` keeps up to 7 daily copies;
 *  - a document that cannot be parsed is NEVER overwritten: it is kept under `state.corrupt.*`.
 */

export const SCHEMA_VERSION = 2;

export interface MemberRow {
  id: number;
  name: string;
  phone: string;
  photo_url: string;
  join_date: string;
  is_active: number;
  notes: string;
  created_at: string;
  updated_at: string;
}
export interface MealRow {
  id: number;
  member_id: number;
  meal_date: string;
  month_key: string;
  breakfast: number;
  lunch: number;
  dinner: number;
  extra_meal: number;
  total_meal: number;
  note: string;
  created_at: string;
  updated_at: string;
}
export interface BazarRow {
  id: number;
  bazar_date: string;
  month_key: string;
  title: string;
  shopper_member_id: number | null;
  shopper_name: string;
  total_amount: number;
  notes: string;
  created_at: string;
  updated_at: string;
}
export interface BazarItemRow {
  id: number;
  transaction_id: number;
  item_name: string;
  quantity: number;
  unit: string;
  unit_price: number;
  total_price: number;
  created_at: string;
  updated_at: string;
}
export interface ExpenseRow {
  id: number;
  expense_date: string;
  month_key: string;
  expense_type: 'individual' | 'common';
  member_id: number | null;
  title: string;
  amount: number;
  notes: string;
  created_at: string;
  updated_at: string;
}
export interface DepositRow {
  id: number;
  member_id: number;
  deposit_date: string;
  month_key: string;
  amount: number;
  payment_method: string;
  note: string;
  created_at: string;
  updated_at: string;
}
export interface ReportRow {
  id: number;
  month_key: string;
  is_closed: number;
  closed_at: string | null;
  closed_by: string | null;
  total_members: number;
  total_deposit: number;
  total_bazar_expense: number;
  total_common_extra_expense: number;
  total_individual_expense: number;
  total_meals: number;
  meal_rate: number;
  total_expense: number;
  remaining_balance: number;
  snapshot_json: string;
  created_at: string;
  updated_at: string;
}
export interface AuditRow {
  id: number;
  admin_username: string;
  action: string;
  entity_type: string;
  entity_id: string;
  summary: string;
  ip_address: string;
  created_at: string;
}

export const TABLES = [
  'members',
  'meals',
  'bazar_transactions',
  'bazar_items',
  'individual_expenses',
  'deposits',
  'monthly_reports',
  'audit_logs',
] as const;
export type TableName = (typeof TABLES)[number];

export interface LedgerState {
  schema: number;
  counters: Record<TableName, number>;
  settings: Record<string, string>;
  members: MemberRow[];
  meals: MealRow[];
  bazar_transactions: BazarRow[];
  bazar_items: BazarItemRow[];
  individual_expenses: ExpenseRow[];
  deposits: DepositRow[];
  monthly_reports: ReportRow[];
  audit_logs: AuditRow[];
}

export interface Meta {
  onboarded: boolean;
  createdAt: string;
  lastBackupAt: string | null;
  pinHash: string | null;
  pinSalt: string | null;
  installSnoozedUntil: number;
  installedSeen: boolean;
}

export const DEFAULT_SETTINGS: Record<string, string> = {
  mess_name: 'My Mess',
  mess_name_bn: 'আমার মেস',
  currency_symbol: '৳',
  enable_breakfast: 'false',
  default_language: 'bn',
  demo_mode: 'false',
};

export function emptyState(): LedgerState {
  return {
    schema: SCHEMA_VERSION,
    counters: {
      members: 0,
      meals: 0,
      bazar_transactions: 0,
      bazar_items: 0,
      individual_expenses: 0,
      deposits: 0,
      monthly_reports: 0,
      audit_logs: 0,
    },
    settings: { ...DEFAULT_SETTINGS },
    members: [],
    meals: [],
    bazar_transactions: [],
    bazar_items: [],
    individual_expenses: [],
    deposits: [],
    monthly_reports: [],
    audit_logs: [],
  };
}

export function emptyMeta(): Meta {
  return {
    onboarded: false,
    createdAt: new Date().toISOString(),
    lastBackupAt: null,
    pinHash: null,
    pinSalt: null,
    installSnoozedUntil: 0,
    installedSeen: false,
  };
}

/* ------------------------------------------------------------------ */
/* Storage drivers                                                     */
/* ------------------------------------------------------------------ */

export interface StorageDriver {
  read(key: string): Promise<string | null>;
  write(key: string, value: string): Promise<void>;
  remove(key: string): Promise<void>;
  keys(prefix: string): Promise<string[]>;
}

export function memoryDriver(): StorageDriver & { data: Map<string, string> } {
  const data = new Map<string, string>();
  return {
    data,
    async read(k) {
      return data.has(k) ? (data.get(k) as string) : null;
    },
    async write(k, v) {
      data.set(k, v);
    },
    async remove(k) {
      data.delete(k);
    },
    async keys(prefix) {
      return [...data.keys()].filter((k) => k.startsWith(prefix));
    },
  };
}

function localStorageDriver(): StorageDriver {
  const P = 'mv:';
  return {
    async read(k) {
      return window.localStorage.getItem(P + k);
    },
    async write(k, v) {
      window.localStorage.setItem(P + k, v);
    },
    async remove(k) {
      window.localStorage.removeItem(P + k);
    },
    async keys(prefix) {
      const out: string[] = [];
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        if (key && key.startsWith(P + prefix)) out.push(key.slice(P.length));
      }
      return out;
    },
  };
}

function idbDriver(): Promise<StorageDriver> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open('messview', 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore('kv');
    };
    req.onerror = () => reject(req.error ?? new Error('IndexedDB open failed'));
    req.onblocked = () => reject(new Error('IndexedDB blocked'));
    req.onsuccess = () => {
      const idb = req.result;
      idb.onversionchange = () => idb.close();
      const run = <T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>) =>
        new Promise<T>((res, rej) => {
          const tx = idb.transaction('kv', mode);
          const r = fn(tx.objectStore('kv'));
          tx.oncomplete = () => res(r.result);
          tx.onerror = () => rej(tx.error ?? new Error('IndexedDB transaction failed'));
          tx.onabort = () => rej(tx.error ?? new Error('IndexedDB transaction aborted'));
        });
      resolve({
        async read(k) {
          const v = await run('readonly', (s) => s.get(k));
          return typeof v === 'string' ? v : null;
        },
        async write(k, v) {
          await run('readwrite', (s) => s.put(v, k));
        },
        async remove(k) {
          await run('readwrite', (s) => s.delete(k));
        },
        async keys(prefix) {
          const all = await run('readonly', (s) => s.getAllKeys());
          return (all as IDBValidKey[]).map(String).filter((k) => k.startsWith(prefix));
        },
      });
    };
  });
}

async function pickDriver(): Promise<StorageDriver> {
  try {
    const d = await idbDriver();
    // Prove it really works (some private modes open fine but fail on write).
    await d.write('__probe', '1');
    await d.remove('__probe');
    return d;
  } catch {
    try {
      window.localStorage.setItem('mv:__probe', '1');
      window.localStorage.removeItem('mv:__probe');
      return localStorageDriver();
    } catch {
      return memoryDriver();
    }
  }
}

/* ------------------------------------------------------------------ */
/* Store                                                               */
/* ------------------------------------------------------------------ */

export class StoreCorruptError extends Error {
  constructor(public savedAs: string) {
    super('Saved data could not be read');
  }
}

let driver: StorageDriver | null = null;
let state: LedgerState = emptyState();
let meta: Meta = emptyMeta();
let ready = false;
let persistChain: Promise<void> = Promise.resolve();
let lastWrittenJson = '';
let channel: BroadcastChannel | null = null;

function clone<T>(v: T): T {
  return typeof structuredClone === 'function' ? structuredClone(v) : (JSON.parse(JSON.stringify(v)) as T);
}

function isRows(v: unknown): v is unknown[] {
  return Array.isArray(v);
}

/** Validates the shape of a loaded document and fills anything an older version lacked. */
export function normalizeState(raw: unknown): LedgerState {
  if (!raw || typeof raw !== 'object') throw new Error('not an object');
  const r = raw as Record<string, unknown>;
  const s = emptyState();
  for (const t of TABLES) {
    const rows = r[t];
    if (rows === undefined) continue;
    if (!isRows(rows)) throw new Error(`table ${t} is not a list`);
    (s as unknown as Record<string, unknown>)[t] = rows;
  }
  if (r.settings && typeof r.settings === 'object') {
    for (const [k, v] of Object.entries(r.settings as Record<string, unknown>)) {
      if (typeof v === 'string') s.settings[k] = v;
    }
  }
  const counters = (r.counters ?? {}) as Record<string, unknown>;
  for (const t of TABLES) {
    const maxId = (s[t] as Array<{ id: number }>).reduce((m, row) => Math.max(m, Number(row.id) || 0), 0);
    const saved = Number(counters[t]) || 0;
    s.counters[t] = Math.max(maxId, saved);
  }
  s.schema = SCHEMA_VERSION;
  return s;
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

async function readJson<T>(key: string): Promise<T | null> {
  const raw = await (driver as StorageDriver).read(key);
  if (raw === null) return null;
  return JSON.parse(raw) as T;
}

/** Opens the database. Safe to call more than once. Pass a driver in tests. */
export async function initStore(custom?: StorageDriver): Promise<void> {
  if (ready) return;
  driver = custom ?? (await pickDriver());

  // meta (PIN, onboarding flag, ...)
  try {
    const m = await readJson<Partial<Meta>>('meta');
    meta = { ...emptyMeta(), ...(m ?? {}) };
  } catch {
    meta = emptyMeta();
  }

  // ledger
  const rawState = await driver.read('state');
  if (rawState === null) {
    state = emptyState();
    // A brand-new install, or storage was wiped. If an old copy exists, offer it instead of nothing.
    const prev = await driver.read('state.prev');
    if (prev !== null) {
      try {
        state = normalizeState(JSON.parse(prev));
      } catch {
        /* ignore, start empty */
      }
    }
  } else {
    try {
      state = normalizeState(JSON.parse(rawState));
    } catch {
      const savedAs = `state.corrupt.${Date.now()}`;
      await driver.write(savedAs, rawState);
      // Try the previous good copy before giving up.
      const prev = await driver.read('state.prev');
      let recovered = false;
      if (prev !== null) {
        try {
          state = normalizeState(JSON.parse(prev));
          recovered = true;
        } catch {
          /* fall through */
        }
      }
      if (!recovered) throw new StoreCorruptError(savedAs);
    }
  }
  lastWrittenJson = JSON.stringify(state);
  ready = true;

  try {
    if (typeof BroadcastChannel !== 'undefined') {
      channel = new BroadcastChannel('messview-data');
      channel.onmessage = async (ev) => {
        if (ev.data?.type !== 'changed') return;
        try {
          const raw = await (driver as StorageDriver).read('state');
          if (raw && raw !== lastWrittenJson) {
            state = normalizeState(JSON.parse(raw));
            lastWrittenJson = raw;
            const m = await readJson<Partial<Meta>>('meta');
            if (m) meta = { ...emptyMeta(), ...m };
            window.dispatchEvent(new CustomEvent('messview:external-change'));
          }
        } catch {
          /* ignore */
        }
      };
    }
  } catch {
    channel = null;
  }

  // Ask the browser not to evict our data under storage pressure (best effort).
  try {
    await navigator.storage?.persist?.();
  } catch {
    /* ignore */
  }
}

export function isReady(): boolean {
  return ready;
}

export function getState(): LedgerState {
  return state;
}

/** Replace the whole ledger (used by restore). */
export function replaceState(next: LedgerState): void {
  state = next;
}

export function nextId(table: TableName): number {
  state.counters[table] += 1;
  return state.counters[table];
}

/**
 * Runs `fn` against the live state. If it throws, the state is restored exactly as it was
 * and the error is re-thrown. On success the change is scheduled for saving.
 */
export function transaction<T>(fn: (s: LedgerState) => T): T {
  const before = clone(state);
  try {
    const out = fn(state);
    schedulePersist();
    return out;
  } catch (err) {
    state = before;
    throw err;
  }
}

function schedulePersist(): void {
  const snapshot = JSON.stringify(state);
  persistChain = persistChain
    .catch(() => undefined)
    .then(async () => {
      const d = driver as StorageDriver;
      if (snapshot === lastWrittenJson) return;
      if (lastWrittenJson) await d.write('state.prev', lastWrittenJson);
      await d.write('state', snapshot);
      lastWrittenJson = snapshot;
      await dailySnapshot(snapshot);
      try {
        channel?.postMessage({ type: 'changed' });
      } catch {
        /* ignore */
      }
    });
}

async function dailySnapshot(json: string): Promise<void> {
  const d = driver as StorageDriver;
  const key = `snap:${today()}`;
  // Keep the FIRST save of each day (= the state at the start of that day's work is the previous
  // day's last save, so overwriting with the latest would defeat the purpose of a safety copy).
  const existing = await d.read(key);
  if (existing === null) await d.write(key, json);
  const keys = (await d.keys('snap:')).sort();
  for (const old of keys.slice(0, Math.max(0, keys.length - 7))) await d.remove(old);
}

/** Resolves when every change made so far is safely written. */
export async function flush(): Promise<void> {
  await persistChain;
}

export async function listSnapshots(): Promise<string[]> {
  if (!driver) return [];
  return (await driver.keys('snap:')).map((k) => k.slice(5)).sort().reverse();
}

export async function loadSnapshot(date: string): Promise<LedgerState | null> {
  if (!driver) return null;
  const raw = await driver.read(`snap:${date}`);
  if (!raw) return null;
  return normalizeState(JSON.parse(raw));
}

/** Writes the meta document (PIN, onboarding, ...). */
export function getMeta(): Meta {
  return meta;
}
export async function updateMeta(patch: Partial<Meta>): Promise<void> {
  meta = { ...meta, ...patch };
  if (driver) {
    await driver.write('meta', JSON.stringify(meta));
    try {
      channel?.postMessage({ type: 'changed' });
    } catch {
      /* ignore */
    }
  }
}

/** Approximate size of the saved ledger, for the settings screen. */
export function approxBytes(): number {
  return lastWrittenJson.length;
}

/** Test helper: forget everything held in memory. */
export function __resetForTests(): void {
  driver = null;
  state = emptyState();
  meta = emptyMeta();
  ready = false;
  persistChain = Promise.resolve();
  lastWrittenJson = '';
  channel = null;
}

/** Erases the live ledger and settings of this app (corrupt copies and daily snapshots are kept). */
export async function wipeAll(): Promise<void> {
  const d = driver ?? (await pickDriver());
  await d.remove('state');
  await d.remove('state.prev');
  await d.remove('meta');
}
