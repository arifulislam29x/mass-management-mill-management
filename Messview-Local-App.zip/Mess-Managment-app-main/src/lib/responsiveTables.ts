import { useEffect } from 'react';

/**
 * On phones every <table> is shown as stacked cards. CSS needs a label per cell,
 * so we copy each column header onto its cells (and keep it updated as data changes).
 */
function enhance(table: HTMLTableElement) {
  const headers = Array.from(table.querySelectorAll('thead th')).map((th) => (th.textContent || '').trim());
  // Wide matrices (e.g. 31-day meal grid) stay as horizontally scrollable tables inside their container
  if (headers.length === 0 || headers.length > 10) {
    table.classList.remove('rt');
    return;
  }
  table.classList.add('rt');
  table.querySelectorAll('tbody tr, tfoot tr').forEach((tr) => {
    let col = 0;
    Array.from(tr.children).forEach((cell) => {
      const td = cell as HTMLElement;
      const span = Number(td.getAttribute('colspan') || 1);
      const label = span === 1 ? headers[col] : '';
      if (label && td.getAttribute('data-label') !== label) td.setAttribute('data-label', label);
      col += span;
    });
  });
}

export function useResponsiveTables() {
  useEffect(() => {
    let frame = 0;
    const run = () => {
      frame = 0;
      document.querySelectorAll('table').forEach((t) => enhance(t as HTMLTableElement));
    };
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(run);
    };
    run();
    const observer = new MutationObserver(schedule);
    observer.observe(document.body, { childList: true, subtree: true });
    return () => {
      observer.disconnect();
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);
}
