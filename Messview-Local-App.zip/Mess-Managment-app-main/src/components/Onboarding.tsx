import { useRef, useState } from 'react';
import { ArrowRight, FileUp, Sparkles, UtensilsCrossed } from 'lucide-react';
import type { Language } from '../types.ts';
import { apiRequest, errorText } from '../lib/api.ts';
import { updateMeta } from '../lib/local/store.ts';

export function Onboarding({ lang, onDone, onToggleLang }: { lang: Language; onDone: (lang: Language) => void; onToggleLang: () => void }) {
  const bn = lang === 'bn';
  const [name, setName] = useState('');
  const [breakfast, setBreakfast] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const file = useRef<HTMLInputElement>(null);

  const finish = async (afterSettings?: () => Promise<void>) => {
    setBusy(true);
    setError('');
    try {
      const n = name.trim() || (bn ? 'আমার মেস' : 'My Mess');
      await apiRequest('/api/admin/settings', {
        method: 'PUT',
        body: {
          mess_name: n,
          mess_name_bn: n,
          currency_symbol: '৳',
          enable_breakfast: breakfast ? 'true' : 'false',
          default_language: lang,
        },
      });
      if (afterSettings) await afterSettings();
      await updateMeta({ onboarded: true });
      onDone(lang);
    } catch (e) {
      setError(errorText(e, bn));
    } finally {
      setBusy(false);
    }
  };

  const restore = async (f: File) => {
    setBusy(true);
    setError('');
    try {
      const data = JSON.parse(await f.text());
      await apiRequest('/api/admin/restore', { method: 'POST', body: data });
      await updateMeta({ onboarded: true });
      onDone(lang);
    } catch (e) {
      setError(e instanceof SyntaxError ? (bn ? 'এটি সঠিক ব্যাকআপ ফাইল নয়।' : 'That is not a valid backup file.') : errorText(e, bn));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-emerald-600 via-emerald-700 to-teal-900 px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(1.5rem,env(safe-area-inset-top))]">
      <div className="flex justify-end">
        <button type="button" onClick={onToggleLang} className="rounded-full bg-white/15 px-3 py-1.5 text-xs font-semibold text-white">
          {bn ? 'English' : 'বাংলা'}
        </button>
      </div>
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center">
        <div className="page-enter">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-emerald-700 shadow-xl">
            <UtensilsCrossed className="h-8 w-8" />
          </span>
          <h1 className="mt-5 text-3xl font-extrabold tracking-tight text-white">{bn ? 'স্বাগতম!' : 'Welcome!'}</h1>
          <p className="mt-2 text-emerald-100">
            {bn
              ? 'মিল, বাজার, জমা-খরচ আর মাসিক হিসাব — সবকিছু এই ফোনেই। কোনো লগইন নেই, সার্ভার নেই; আপনার ডাটা অন্য কেউ দেখতে পারবে না।'
              : 'Meals, bazar, deposits and monthly settlement — all on this phone. No login, no server; nobody else can see your data.'}
          </p>

          <div className="mt-7 space-y-4 rounded-3xl bg-white p-5 shadow-2xl dark:bg-slate-900">
            <label className="block">
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{bn ? 'মেসের নাম' : 'Mess name'}</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={80}
                placeholder={bn ? 'যেমন: সবুজ মেস' : 'e.g. Green Mess'}
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 text-base text-slate-900 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
            </label>
            <label className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 px-4 py-3 dark:bg-slate-800">
              <span className="text-sm text-slate-700 dark:text-slate-200">{bn ? 'সকালের নাস্তার মিল গোনা হবে' : 'Count breakfast meals'}</span>
              <input type="checkbox" checked={breakfast} onChange={(e) => setBreakfast(e.target.checked)} className="h-5 w-5 accent-emerald-600" />
            </label>

            {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300">{error}</p>}

            <button type="button" disabled={busy} onClick={() => void finish()} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-600 py-3.5 text-base font-bold text-white shadow-lg shadow-emerald-600/30 transition active:scale-[0.98] hover:bg-emerald-700 disabled:opacity-60">
              {bn ? 'শুরু করুন' : 'Get started'} <ArrowRight className="h-5 w-5" />
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" disabled={busy} onClick={() => void finish(async () => void (await apiRequest('/api/admin/demo/load', { method: 'POST' })))} className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">
                <Sparkles className="h-4 w-4 text-amber-500" />
                {bn ? 'ডেমো ডাটা দিয়ে দেখুন' : 'Try with demo data'}
              </button>
              <button type="button" disabled={busy} onClick={() => file.current?.click()} className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">
                <FileUp className="h-4 w-4 text-emerald-600" />
                {bn ? 'ব্যাকআপ থেকে ফেরান' : 'Restore backup'}
              </button>
              <input ref={file} type="file" accept="application/json,.json" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) void restore(f); }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
