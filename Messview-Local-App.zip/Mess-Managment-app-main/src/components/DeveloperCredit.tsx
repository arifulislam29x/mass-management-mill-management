import React from 'react';
import { Code2, Phone } from 'lucide-react';
import type { Language } from '../types.ts';

export const DEVELOPER = {
  name: 'Ariful Islam',
  linkedin: 'https://www.linkedin.com/in/arifulislam29x/',
  facebook: 'https://www.facebook.com/ArifulIslam29x',
  phoneLocal: '01867139586',
  phoneIntl: '8801867139586',
};

function whatsappLink(lang: Language) {
  const text =
    lang === 'bn'
      ? 'আসসালামু আলাইকুম, Messview অ্যাপে আপনার ডেভেলপার ইনফো দেখে যোগাযোগ করছি। আমার একটি ওয়েবসাইট/অ্যাপ বানানো প্রয়োজন।'
      : 'Hello, I found you through the Messview app. I need a website / app built.';
  return `https://wa.me/${DEVELOPER.phoneIntl}?text=${encodeURIComponent(text)}`;
}

export function WhatsAppIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.88 1.21 3.08.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.08 1.76-.72 2.01-1.41.25-.69.25-1.29.17-1.41-.07-.12-.27-.2-.57-.35zM12.04 21.5h-.01a9.45 9.45 0 0 1-4.82-1.32l-.35-.2-3.58.94.96-3.49-.23-.36a9.43 9.43 0 0 1-1.45-5.03c0-5.22 4.25-9.47 9.48-9.47 2.53 0 4.9.99 6.69 2.78a9.4 9.4 0 0 1 2.77 6.7c0 5.22-4.25 9.47-9.46 9.47zM20.1 3.9A11.4 11.4 0 0 0 12.04.5C5.75.5.63 5.62.63 11.9c0 2.01.53 3.97 1.52 5.7L.5 23.5l6.05-1.59a11.4 11.4 0 0 0 5.48 1.4h.01c6.29 0 11.41-5.12 11.41-11.41 0-3.05-1.19-5.91-3.35-8.1z" />
    </svg>
  );
}

export function LinkedInIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M20.45 20.45h-3.56v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.22 0z" />
    </svg>
  );
}

export function FacebookIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.7 4.53-4.7 1.31 0 2.69.24 2.69.24v2.97h-1.51c-1.49 0-1.96.93-1.96 1.89v2.26h3.33l-.53 3.49h-2.8V24C19.61 23.1 24 18.1 24 12.07z" />
    </svg>
  );
}

const linkBase =
  'inline-flex items-center justify-center gap-2 rounded-lg px-3.5 py-2 text-sm font-semibold transition-all hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-offset-2';

/** Full developer / "hire me" card. */
export function DeveloperCard({ lang, className = '' }: { lang: Language; className?: string }) {
  const bn = lang === 'bn';
  return (
    <section
      aria-labelledby="dev-title"
      className={`overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 ${className}`}
    >
      <div className="h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-500" />
      <div className="p-5 sm:p-6">
        <div className="flex items-start gap-4">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-xl font-bold text-white shadow-md shadow-emerald-600/25">
            AI
          </span>
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              <Code2 className="h-3.5 w-3.5" />
              {bn ? 'ডেভেলপার' : 'Developer'}
            </p>
            <h2 id="dev-title" className="mt-0.5 text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100">
              {DEVELOPER.name}
            </h2>
            <p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              {bn
                ? 'এই Messview অ্যাপটি তৈরি করেছেন আরিফুল ইসলাম।'
                : 'Messview was designed and built by Ariful Islam.'}
            </p>
          </div>
        </div>

        <div className="mt-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm leading-relaxed text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-100">
          {bn
            ? 'আপনার ব্যবসা বা প্রতিষ্ঠানের জন্য ওয়েবসাইট, ওয়েব অ্যাপ বা মোবাইল অ্যাপ বানাতে চান? নির্দ্বিধায় যোগাযোগ করুন।'
            : 'Need a website, web app or mobile app for your business? Feel free to get in touch.'}
        </div>

        <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
          <a
            href={whatsappLink(lang)}
            target="_blank"
            rel="noopener noreferrer"
            className={`${linkBase} bg-[#25D366] text-white hover:bg-[#1ebe5b]`}
          >
            <WhatsAppIcon />
            WhatsApp · {DEVELOPER.phoneLocal}
          </a>
          <a href={`tel:+${DEVELOPER.phoneIntl}`} className={`${linkBase} border border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800`}>
            <Phone className="h-4 w-4" />
            {bn ? 'কল করুন' : 'Call'}
          </a>
          <a
            href={DEVELOPER.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className={`${linkBase} bg-[#0A66C2] text-white hover:bg-[#0958a8]`}
          >
            <LinkedInIcon />
            LinkedIn
          </a>
          <a
            href={DEVELOPER.facebook}
            target="_blank"
            rel="noopener noreferrer"
            className={`${linkBase} bg-[#1877F2] text-white hover:bg-[#1468d6]`}
          >
            <FacebookIcon />
            Facebook
          </a>
        </div>
      </div>
    </section>
  );
}

/** Slim one-line credit used in page footers. */
export function DeveloperFooter({ lang, className = '' }: { lang: Language; className?: string }) {
  const bn = lang === 'bn';
  const iconLink =
    'inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white';
  return (
    <footer
      className={`no-print flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-5 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400 sm:flex-row ${className}`}
    >
      <p className="text-center sm:text-left">
        {bn ? 'ডেভেলপ করেছেন' : 'Developed by'}{' '}
        <a href={DEVELOPER.linkedin} target="_blank" rel="noopener noreferrer" className="font-semibold text-slate-700 hover:text-emerald-600 dark:text-slate-200 dark:hover:text-emerald-400">
          {DEVELOPER.name}
        </a>
        <span className="mx-1.5 text-slate-300 dark:text-slate-600">·</span>
        {bn ? 'ওয়েবসাইট/অ্যাপ লাগলে যোগাযোগ করুন' : 'Need a website or app? Contact me'}
      </p>
      <div className="flex items-center gap-1">
        <a href={whatsappLink(lang)} target="_blank" rel="noopener noreferrer" className={iconLink} aria-label="WhatsApp" title={`WhatsApp ${DEVELOPER.phoneLocal}`}>
          <WhatsAppIcon />
        </a>
        <a href={DEVELOPER.linkedin} target="_blank" rel="noopener noreferrer" className={iconLink} aria-label="LinkedIn" title="LinkedIn">
          <LinkedInIcon />
        </a>
        <a href={DEVELOPER.facebook} target="_blank" rel="noopener noreferrer" className={iconLink} aria-label="Facebook" title="Facebook">
          <FacebookIcon />
        </a>
      </div>
    </footer>
  );
}
