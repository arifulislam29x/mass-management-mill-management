import React, { useState } from 'react';
import { Download, RefreshCw, Share, X } from 'lucide-react';
import type { Language } from '../types.ts';
import { Modal } from './ui.tsx';

export function InstallButton({
  lang,
  canInstall,
  needsIOSHint,
  onInstall,
  className = '',
}: {
  lang: Language;
  canInstall: boolean;
  needsIOSHint: boolean;
  onInstall: () => void;
  className?: string;
}) {
  const bn = lang === 'bn';
  const [iosOpen, setIosOpen] = useState(false);
  if (!canInstall && !needsIOSHint) return null;
  return (
    <>
      <button
        type="button"
        onClick={() => (canInstall ? onInstall() : setIosOpen(true))}
        className={`inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 transition-colors hover:bg-emerald-100 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-300 ${className}`}
      >
        <Download className="h-3.5 w-3.5" />
        {bn ? 'অ্যাপ ইনস্টল' : 'Install app'}
      </button>
      <Modal
        open={iosOpen}
        onClose={() => setIosOpen(false)}
        title={bn ? 'iPhone-এ ইনস্টল করুন' : 'Install on iPhone / iPad'}
        maxWidthClass="max-w-sm"
      >
        <ol className="space-y-3 text-sm text-slate-700 dark:text-slate-300">
          <li className="flex gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-xs font-bold text-white">1</span>
            <span>
              {bn ? 'Safari-তে এই সাইট খুলুন এবং নিচের ' : 'Open this site in Safari and tap the '}
              <Share className="inline h-4 w-4 align-text-bottom" />
              {bn ? ' শেয়ার বাটনে চাপ দিন।' : ' Share button.'}
            </span>
          </li>
          <li className="flex gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-xs font-bold text-white">2</span>
            <span>{bn ? '"Add to Home Screen" বেছে নিন।' : 'Choose “Add to Home Screen”.'}</span>
          </li>
          <li className="flex gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-xs font-bold text-white">3</span>
            <span>{bn ? '"Add" চাপুন — হোম স্ক্রিনে Messview অ্যাপ দেখা যাবে।' : 'Tap “Add” — Messview appears on your home screen.'}</span>
          </li>
        </ol>
      </Modal>
    </>
  );
}

export function UpdateBanner({ lang, onApply, onDismiss }: { lang: Language; onApply: () => void; onDismiss: () => void }) {
  const bn = lang === 'bn';
  return (
    <div
      role="status"
      className="fixed inset-x-3 bottom-20 z-[60] mx-auto flex max-w-md items-center gap-3 rounded-xl border border-emerald-200 bg-white px-4 py-3 shadow-xl dark:border-emerald-900 dark:bg-slate-900 lg:bottom-5 lg:left-auto lg:right-5 lg:mx-0"
    >
      <RefreshCw className="h-5 w-5 shrink-0 text-emerald-600" />
      <p className="flex-1 text-sm font-medium text-slate-800 dark:text-slate-100">
        {bn ? 'অ্যাপের নতুন সংস্করণ এসেছে' : 'A new version is available'}
      </p>
      <button type="button" onClick={onApply} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700">
        {bn ? 'আপডেট' : 'Update'}
      </button>
      <button type="button" onClick={onDismiss} aria-label="Dismiss" className="rounded p-1 text-slate-400 hover:text-slate-700">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
