import React, { useEffect, useState } from 'react';
import { Database, Download, History, KeyRound, RotateCcw, Share2, Upload } from 'lucide-react';
import type { AuditLogRecord, Language } from '../types.ts';
import { apiRequest } from '../lib/api.ts';
import { tDict } from '../lib/i18n.ts';
import { ConfirmModal } from './ui.tsx';
import { approxBytes, flush, getMeta, listSnapshots, loadSnapshot, replaceState, transaction, updateMeta } from '../lib/local/store.ts';
import { hasPin, removePin, setPin } from '../lib/local/lock.ts';

export function AdminSettingsTab({
  settings,
  lang,
  authToken,
  onDataChanged,
  onNotify,
}: {
  settings: Record<string, string>;
  lang: Language;
  authToken: string;
  onDataChanged: () => void;
  onNotify: (type: 'success' | 'error', msg: string) => void;
}) {
  const d = tDict(lang);
  const [messNameEn, setMessNameEn] = useState(settings.mess_name || 'Greenview Mess');
  const [messNameBn, setMessNameBn] = useState(settings.mess_name_bn || 'গ্রিনভিউ মেস');
  const [currency, setCurrency] = useState(settings.currency_symbol || '৳');
  const [enableBreakfast, setEnableBreakfast] = useState(settings.enable_breakfast === 'true');
  const [defaultLang, setDefaultLang] = useState<'bn' | 'en'>(
    settings.default_language === 'en' ? 'en' : 'bn'
  );

  const bn = lang === 'bn';
  const [pinValue, setPinValue] = useState('');
  const [pinOn, setPinOn] = useState(hasPin());
  const [lastBackup, setLastBackup] = useState<string | null>(getMeta().lastBackupAt);
  const [snapshots, setSnapshots] = useState<string[]>([]);
  const [pendingSnapshot, setPendingSnapshot] = useState<string | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);
  const [saving, setSaving] = useState(false);

  const [confirmAction, setConfirmAction] = useState<'load_demo' | 'clear_data' | null>(null);
  const [pendingRestoreJson, setPendingRestoreJson] = useState<unknown | null>(null);

  const loadAuditLogs = async () => {
    try {
      const res = await apiRequest<{ logs: AuditLogRecord[] }>('/api/admin/audit-logs?limit=100', {
        token: authToken,
      });
      setAuditLogs(res.logs);
    } catch {
      setAuditLogs([]);
    }
  };

  useEffect(() => {
    loadAuditLogs();
    void listSnapshots().then(setSnapshots);
  }, [authToken]);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await apiRequest('/api/admin/settings', {
        method: 'PUT',
        token: authToken,
        body: {
          mess_name: messNameEn.trim(),
          mess_name_bn: messNameBn.trim(),
          currency_symbol: currency.trim(),
          enable_breakfast: enableBreakfast ? 'true' : 'false',
          default_language: defaultLang,
        },
      });
      onDataChanged();
      await loadAuditLogs();
      onNotify('success', 'Settings saved');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSavePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{4,8}$/.test(pinValue)) {
      onNotify('error', bn ? 'পিন ৪ থেকে ৮ সংখ্যার হতে হবে' : 'PIN must be 4–8 digits');
      return;
    }
    try {
      await setPin(pinValue);
      setPinValue('');
      setPinOn(true);
      onNotify('success', bn ? 'অ্যাপ লক চালু হয়েছে' : 'App lock enabled');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed');
    }
  };

  const handleRemovePin = async () => {
    await removePin();
    setPinOn(false);
    onNotify('success', bn ? 'অ্যাপ লক বন্ধ হয়েছে' : 'App lock disabled');
  };

  const executeSnapshotRestore = async () => {
    if (!pendingSnapshot) return;
    setSaving(true);
    try {
      const snap = await loadSnapshot(pendingSnapshot);
      if (!snap) throw new Error(bn ? 'কপিটি পাওয়া যায়নি' : 'Copy not found');
      transaction(() => replaceState(snap));
      await flush();
      setPendingSnapshot(null);
      onDataChanged();
      await loadAuditLogs();
      onNotify('success', bn ? 'ডাটা ফিরিয়ে আনা হয়েছে' : 'Data restored');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Restore failed');
    } finally {
      setSaving(false);
    }
  };

  const makeBackupFile = async () => {
    const data = await apiRequest<unknown>('/api/admin/backup', { token: authToken });
    const name = `messview_backup_${new Date().toISOString().slice(0, 10)}.json`;
    return new File([JSON.stringify(data, null, 2)], name, { type: 'application/json' });
  };

  const markBackedUp = async () => {
    const iso = new Date().toISOString();
    await updateMeta({ lastBackupAt: iso });
    setLastBackup(iso);
    onDataChanged();
  };

  const handleDownloadBackup = async () => {
    try {
      const file = await makeBackupFile();
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.setTimeout(() => URL.revokeObjectURL(url), 10_000);
      await markBackedUp();
      onNotify('success', bn ? 'ব্যাকআপ ফাইল সেভ হয়েছে' : 'Backup saved');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Backup failed');
    }
  };

  const handleShareBackup = async () => {
    try {
      const file = await makeBackupFile();
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: 'Messview backup' });
        await markBackedUp();
      } else {
        await handleDownloadBackup();
      }
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') onNotify('error', err instanceof Error ? err.message : 'Share failed');
    }
  };

  const handleSelectRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        setPendingRestoreJson(parsed);
      } catch {
        onNotify('error', 'Invalid JSON backup file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const executeRestore = async () => {
    if (!pendingRestoreJson) return;
    setSaving(true);
    try {
      await apiRequest('/api/admin/restore', {
        method: 'POST',
        token: authToken,
        body: pendingRestoreJson,
      });
      setPendingRestoreJson(null);
      onDataChanged();
      await loadAuditLogs();
      onNotify('success', 'Database restored successfully');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Restore failed');
    } finally {
      setSaving(false);
    }
  };

  const executeDemoAction = async () => {
    if (!confirmAction) return;
    setSaving(true);
    try {
      const endpoint =
        confirmAction === 'load_demo' ? '/api/admin/demo/load' : '/api/admin/demo/clear';
      await apiRequest(endpoint, { method: 'POST', token: authToken });
      setConfirmAction(null);
      onDataChanged();
      await loadAuditLogs();
      onNotify(
        'success',
        confirmAction === 'load_demo' ? 'Demo dataset loaded' : 'All operational data cleared'
      );
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Action failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{d.settings.title}</h2>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* General Settings */}
        <form
          onSubmit={handleSaveSettings}
          className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <h3 className="text-sm font-semibold">{d.settings.general}</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium">{d.settings.messNameEn}</label>
              <input
                type="text"
                required
                value={messNameEn}
                onChange={(e) => setMessNameEn(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium">{d.settings.messNameBn}</label>
              <input
                type="text"
                required
                value={messNameBn}
                onChange={(e) => setMessNameBn(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium">{d.settings.currency}</label>
              <input
                type="text"
                required
                maxLength={5}
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium">{d.settings.defaultLang}</label>
              <select
                value={defaultLang}
                onChange={(e) => setDefaultLang(e.target.value as 'bn' | 'en')}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
              >
                <option value="bn">বাংলা</option>
                <option value="en">English</option>
              </select>
            </div>
          </div>

          <label className="flex items-center gap-2.5 text-sm">
            <input
              type="checkbox"
              checked={enableBreakfast}
              onChange={(e) => setEnableBreakfast(e.target.checked)}
              className="h-4 w-4 rounded accent-emerald-600"
            />
            <span>{d.settings.enableBreakfast}</span>
          </label>

          <button
            type="submit"
            disabled={saving}
            className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            {d.common.save}
          </button>
        </form>

        {/* Backup, Restore & Demo Controls */}
        <div className="space-y-5">
          <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-semibold">{d.settings.backupRestore}</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {bn
                ? 'আপনার ডাটা শুধু এই ফোনে আছে। ফোন হারালে বা অ্যাপ মুছলে ডাটা চলে যাবে — তাই নিয়মিত ব্যাকআপ রাখুন (Google Drive / WhatsApp-এ পাঠিয়ে রাখতে পারেন)।'
                : 'Your data exists only on this phone. If the phone is lost or the app is removed it is gone — keep a regular backup (e.g. send it to Google Drive / WhatsApp).'}
            </p>
            <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
              {bn ? 'সর্বশেষ ব্যাকআপ: ' : 'Last backup: '}
              {lastBackup ? new Date(lastBackup).toLocaleString(bn ? 'bn-BD' : 'en-GB') : bn ? 'এখনো নেওয়া হয়নি' : 'never'}
              {' · '}
              {(approxBytes() / 1024).toFixed(0)} KB
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleShareBackup}
                className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
              >
                <Share2 className="h-4 w-4" />
                {bn ? 'শেয়ার / সেভ করুন' : 'Share / save'}
              </button>
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <Download className="h-4 w-4" />
                {d.settings.downloadBackup}
              </button>
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">
                <Upload className="h-4 w-4" />
                {d.settings.restoreBackup}
                <input
                  type="file"
                  accept="application/json"
                  onChange={handleSelectRestoreFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-semibold">{d.settings.demoSection}</h3>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setConfirmAction('load_demo')}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <Database className="h-4 w-4" />
                {d.settings.loadDemo}
              </button>
              <button
                type="button"
                onClick={() => setConfirmAction('clear_data')}
                className="inline-flex items-center gap-2 rounded-lg border border-red-200 px-3.5 py-2 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400 dark:hover:bg-red-950/30"
              >
                <RotateCcw className="h-4 w-4" />
                {d.settings.clearData}
              </button>
            </div>
          </div>

          <form
            onSubmit={handleSavePin}
            className="space-y-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
          >
            <h3 className="flex items-center gap-2 text-sm font-semibold">
              <KeyRound className="h-4 w-4 text-slate-500" />
              {bn ? 'অ্যাপ লক (পিন)' : 'App lock (PIN)'}
              {pinOn && <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">{bn ? 'চালু' : 'ON'}</span>}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {bn ? 'অ্যাপ খুলতে পিন লাগবে, যাতে ফোন অন্য কারো হাতে গেলেও হিসাব দেখা না যায়।' : 'Ask for a PIN when the app opens, so the ledger stays private if someone else holds your phone.'}
            </p>
            <div className="flex flex-wrap gap-3">
              <input
                type="password"
                inputMode="numeric"
                autoComplete="off"
                maxLength={8}
                placeholder={bn ? (pinOn ? 'নতুন পিন (৪–৮ সংখ্যা)' : 'পিন (৪–৮ সংখ্যা)') : pinOn ? 'New PIN (4–8 digits)' : 'PIN (4–8 digits)'}
                value={pinValue}
                onChange={(e) => setPinValue(e.target.value.replace(/\D/g, ''))}
                className="min-w-0 flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
              />
              <button type="submit" className="rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">
                {pinOn ? (bn ? 'পিন বদলান' : 'Change PIN') : bn ? 'লক চালু করুন' : 'Enable lock'}
              </button>
              {pinOn && (
                <button type="button" onClick={handleRemovePin} className="rounded-lg border border-red-200 px-3.5 py-2 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400">
                  {bn ? 'লক বন্ধ' : 'Turn off'}
                </button>
              )}
            </div>
          </form>

          {snapshots.length > 0 && (
            <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <History className="h-4 w-4 text-slate-500" />
                {bn ? 'স্বয়ংক্রিয় সেভ করা কপি' : 'Automatic daily copies'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {bn ? 'ভুল করে ডাটা মুছে গেলে এখান থেকে আগের দিনের অবস্থায় ফিরতে পারবেন (শেষ ৭ দিন)।' : 'Made a mistake? Roll back to how things were at the start of a recent day (last 7 days).'}
              </p>
              <div className="flex flex-wrap gap-2">
                {snapshots.map((day) => (
                  <button key={day} type="button" onClick={() => setPendingSnapshot(day)} className="rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-xs hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">
                    {day}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Audit Log */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h3 className="text-sm font-semibold">{d.settings.auditLog}</h3>
        </div>
        <div className="max-h-96 overflow-x-auto overflow-y-auto">
          <table className="w-full min-w-[680px] border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-300">
                <th className="px-4 py-2.5">Time (UTC)</th>
                <th className="px-4 py-2.5">Admin</th>
                <th className="px-4 py-2.5">Action</th>
                <th className="px-4 py-2.5">Summary</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {auditLogs.map((log) => (
                <tr key={log.id}>
                  <td className="px-4 py-2 font-mono text-slate-500">{log.created_at}</td>
                  <td className="px-4 py-2 font-medium">{log.admin_username}</td>
                  <td className="px-4 py-2 font-mono text-slate-600 dark:text-slate-300">
                    {log.action} · {log.entity_type}
                  </td>
                  <td className="px-4 py-2 text-slate-700 dark:text-slate-300">{log.summary}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ConfirmModal
        open={confirmAction !== null}
        onClose={() => setConfirmAction(null)}
        onConfirm={executeDemoAction}
        title={confirmAction === 'load_demo' ? d.settings.loadDemo : d.settings.clearData}
        message={
          confirmAction === 'load_demo'
            ? lang === 'bn'
              ? 'ডেমো ডাটা লোড করলে বর্তমান মেস ডাটা প্রতিস্থাপিত হবে। এগোতে চান?'
              : 'Loading sample demo data will replace current mess records. Continue?'
            : lang === 'bn'
              ? 'সকল সদস্য, মিল, বাজার, জমা এবং খরচের তথ্য স্থায়ীভাবে মুছে যাবে। নিশ্চিত?'
              : 'This will permanently wipe all members, meals, bazar, deposits, and expenses. Continue?'
        }
        confirmLabel={d.common.confirm}
        cancelLabel={d.common.cancel}
        danger={confirmAction === 'clear_data'}
        busy={saving}
      />

      <ConfirmModal
        open={pendingSnapshot !== null}
        onClose={() => setPendingSnapshot(null)}
        onConfirm={executeSnapshotRestore}
        title={bn ? 'আগের কপি ফিরিয়ে আনুন' : 'Restore earlier copy'}
        message={
          bn
            ? `${pendingSnapshot} তারিখের শুরুর অবস্থায় ফিরে যাবেন? এর পরের পরিবর্তন হারিয়ে যাবে।`
            : `Go back to the state at the start of ${pendingSnapshot}? Changes made after that will be lost.`
        }
        confirmLabel={d.common.confirm}
        cancelLabel={d.common.cancel}
        danger
        busy={saving}
      />

      <ConfirmModal
        open={pendingRestoreJson !== null}
        onClose={() => setPendingRestoreJson(null)}
        onConfirm={executeRestore}
        title={d.settings.restoreBackup}
        message={
          lang === 'bn'
            ? 'ব্যাকআপ ফাইল রিস্টোর করলে বর্তমান সকল হিসাব ডাটা ওই ব্যাকআপ দ্বারা প্রতিস্থাপিত হবে। নিশ্চিত?'
            : 'Restoring this backup will replace all current database tables atomically. Continue?'
        }
        confirmLabel={d.common.confirm}
        cancelLabel={d.common.cancel}
        busy={saving}
      />
    </div>
  );
}
