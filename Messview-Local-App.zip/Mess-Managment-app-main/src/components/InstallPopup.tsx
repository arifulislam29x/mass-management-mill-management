import { useEffect, useState } from 'react';
import { Chrome, Download, ExternalLink, MoreVertical, Share, ShieldCheck, Smartphone, WifiOff, X } from 'lucide-react';
import type { Language } from '../types.ts';
import { isAndroid, isInAppBrowser, isIOS, useInstallPrompt } from '../lib/pwa.ts';

interface ApkInfo {
  enabled?: boolean;
  apkUrl?: string;
  version?: string;
  sizeMb?: number;
}

async function loadApkInfo(): Promise<ApkInfo | null> {
  try {
    const res = await fetch('/apk-info.json', { cache: 'no-store' });
    if (!res.ok) return null;
    const type = res.headers.get('content-type') || '';
    if (!type.includes('json')) return null; // SPA fallback returned HTML
    const info = (await res.json()) as ApkInfo;
    if (!info.enabled || !info.apkUrl) return null;
    return info;
  } catch {
    return null;
  }
}

function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <li className="flex gap-3">
      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-xs font-bold text-white">{n}</span>
      <span className="text-sm leading-relaxed text-slate-700 dark:text-slate-300">{children}</span>
    </li>
  );
}

/**
 * "Get the app" sheet. Shows the one-tap install when the browser allows it, a real APK download
 * when one is published (public/apk-info.json), and step-by-step help for iPhone / in-app browsers.
 */
export function InstallPopup({ lang, open, onClose }: { lang: Language; open: boolean; onClose: () => void }) {
  const bn = lang === 'bn';
  const { canInstall, installed, install } = useInstallPrompt();
  const [apk, setApk] = useState<ApkInfo | null>(null);
  const [busy, setBusy] = useState(false);
  const ios = isIOS();
  const android = isAndroid();
  const inApp = isInAppBrowser();

  useEffect(() => {
    if (open) void loadApkInfo().then(setApk);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  const doInstall = async () => {
    setBusy(true);
    try {
      if (await install()) onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-slate-950/60 p-0 backdrop-blur-sm sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-labelledby="install-title" onClick={onClose}>
      <div className="page-enter max-h-[92vh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-white pb-[max(1rem,env(safe-area-inset-bottom))] shadow-2xl dark:bg-slate-900 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="relative overflow-hidden rounded-t-3xl bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700 px-6 pb-7 pt-6 text-white sm:rounded-t-3xl">
          <button type="button" onClick={onClose} aria-label={bn ? 'বন্ধ করুন' : 'Close'} className="absolute right-3 top-3 rounded-full p-2 text-white/80 hover:bg-white/15">
            <X className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-4">
            <img src="/icons/icon-192.png" alt="" className="h-16 w-16 rounded-2xl shadow-lg ring-2 ring-white/40" />
            <div>
              <h2 id="install-title" className="text-xl font-bold leading-tight">{bn ? 'Messview অ্যাপ নিন' : 'Get the Messview app'}</h2>
              <p className="mt-0.5 text-sm text-emerald-50">{bn ? 'মেসের হিসাব, এখন আপনার ফোনেই' : 'Your mess ledger, on your phone'}</p>
            </div>
          </div>
        </div>

        <div className="space-y-5 px-6 py-5">
          <ul className="grid grid-cols-3 gap-2 text-center text-[11px] font-medium text-slate-600 dark:text-slate-300">
            <li className="rounded-xl bg-slate-50 p-2.5 dark:bg-slate-800"><ShieldCheck className="mx-auto mb-1 h-5 w-5 text-emerald-600" />{bn ? 'ডাটা শুধু আপনার ফোনে' : 'Data stays on your phone'}</li>
            <li className="rounded-xl bg-slate-50 p-2.5 dark:bg-slate-800"><WifiOff className="mx-auto mb-1 h-5 w-5 text-emerald-600" />{bn ? 'ইন্টারনেট ছাড়াই চলে' : 'Works offline'}</li>
            <li className="rounded-xl bg-slate-50 p-2.5 dark:bg-slate-800"><Smartphone className="mx-auto mb-1 h-5 w-5 text-emerald-600" />{bn ? 'হোম স্ক্রিনে অ্যাপ' : 'Home-screen app'}</li>
          </ul>

          {installed ? (
            <p className="rounded-xl bg-emerald-50 p-4 text-center text-sm font-medium text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300">
              {bn ? '✓ অ্যাপটি এই ফোনে ইনস্টল করা আছে।' : '✓ The app is already installed on this device.'}
            </p>
          ) : inApp ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
              <p className="flex items-center gap-2 font-semibold"><ExternalLink className="h-4 w-4" />{bn ? 'ব্রাউজারে খুলুন' : 'Open in your browser'}</p>
              <p className="mt-1.5 leading-relaxed">
                {bn
                  ? 'ফেসবুক/মেসেঞ্জারের ভেতরের ব্রাউজার থেকে ইনস্টল হয় না। উপরের ডানে ⋮ বা "…" চেপে "Open in Chrome / Safari" বেছে নিন।'
                  : 'Installing does not work inside Facebook/Messenger browsers. Tap ⋮ or “…” at the top right and choose “Open in Chrome / Safari”.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {canInstall && (
                <button type="button" onClick={doInstall} disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-5 py-4 text-base font-bold text-white shadow-lg shadow-emerald-600/30 transition active:scale-[0.98] hover:bg-emerald-700 disabled:opacity-60">
                  <Download className="h-5 w-5" />
                  {bn ? 'এক ট্যাপে অ্যাপ ইনস্টল করুন' : 'Install app — one tap'}
                </button>
              )}

              {apk && android && (
                <a href={apk.apkUrl} download className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-emerald-600 px-5 py-3.5 text-base font-bold text-emerald-700 transition active:scale-[0.98] hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-emerald-950/40">
                  <Download className="h-5 w-5" />
                  {bn ? 'APK ডাউনলোড' : 'Download APK'}
                  <span className="text-xs font-medium opacity-70">{[apk.version && `v${apk.version}`, apk.sizeMb && `${apk.sizeMb} MB`].filter(Boolean).join(' · ')}</span>
                </a>
              )}

              {!canInstall && ios && (
                <ol className="space-y-3 rounded-xl bg-slate-50 p-4 dark:bg-slate-800">
                  <Step n={1}>{bn ? <>Safari-তে সাইটটি খুলে নিচের <Share className="inline h-4 w-4 align-text-bottom" /> শেয়ার বাটনে চাপুন।</> : <>Open this site in Safari and tap <Share className="inline h-4 w-4 align-text-bottom" /> Share.</>}</Step>
                  <Step n={2}>{bn ? '"Add to Home Screen" বেছে নিন।' : 'Choose “Add to Home Screen”.'}</Step>
                  <Step n={3}>{bn ? '"Add" চাপুন — হোম স্ক্রিনে অ্যাপ চলে আসবে।' : 'Tap “Add” — the app appears on your home screen.'}</Step>
                </ol>
              )}

              {!canInstall && !ios && (
                <ol className="space-y-3 rounded-xl bg-slate-50 p-4 dark:bg-slate-800">
                  <Step n={1}>{bn ? <><Chrome className="inline h-4 w-4 align-text-bottom" /> Chrome-এ সাইটটি খুলুন, তারপর উপরের ডানে <MoreVertical className="inline h-4 w-4 align-text-bottom" /> মেনু চাপুন।</> : <>Open the site in <Chrome className="inline h-4 w-4 align-text-bottom" /> Chrome and tap the <MoreVertical className="inline h-4 w-4 align-text-bottom" /> menu.</>}</Step>
                  <Step n={2}>{bn ? '"Install app" বা "Add to Home screen" বেছে নিন।' : 'Choose “Install app” or “Add to Home screen”.'}</Step>
                  <Step n={3}>{bn ? '"Install" চাপুন — ব্যস, অ্যাপ তৈরি!' : 'Tap “Install” — done!'}</Step>
                </ol>
              )}

              {apk && !android && !ios && (
                <a href={apk.apkUrl} download className="block text-center text-sm font-semibold text-emerald-700 underline dark:text-emerald-300">
                  {bn ? 'Android APK ফাইল ডাউনলোড' : 'Download Android APK file'}
                </a>
              )}
            </div>
          )}

          {apk && android && !installed && !inApp && (
            <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
              {bn
                ? 'APK ইনস্টলের সময় ফোন "অজানা উৎস থেকে ইনস্টল" অনুমতি চাইতে পারে — শুধু এই সাইট থেকে নামানো ফাইলের জন্য অনুমতি দিন।'
                : 'Your phone may ask to allow installs from this source — allow it only for the file downloaded from this site.'}
            </p>
          )}
          <p className="text-center text-[11px] text-slate-400">
            {bn ? 'প্রতিটি ফোনের ডাটা আলাদা — অন্য কেউ আপনার হিসাব দেখতে পায় না।' : 'Every phone keeps its own data — nobody else can see your ledger.'}
          </p>
        </div>
      </div>
    </div>
  );
}
