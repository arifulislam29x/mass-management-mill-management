import { useEffect, useRef, useState } from 'react';
import { Delete, Lock } from 'lucide-react';
import type { Language } from '../types.ts';
import { verifyPin } from '../lib/local/lock.ts';

export function LockScreen({ lang, onUnlock, onReset }: { lang: Language; onUnlock: () => void; onReset: () => void }) {
  const bn = lang === 'bn';
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [wait, setWait] = useState(0);
  const fails = useRef(0);

  useEffect(() => {
    if (wait <= 0) return;
    const t = window.setTimeout(() => setWait((w) => w - 1), 1000);
    return () => window.clearTimeout(t);
  }, [wait]);

  const submit = async (value: string) => {
    if (await verifyPin(value)) {
      onUnlock();
      return;
    }
    fails.current += 1;
    setError(true);
    setPin('');
    if (fails.current >= 5) {
      fails.current = 0;
      setWait(30);
    }
    window.setTimeout(() => setError(false), 700);
  };

  const press = (d: string) => {
    if (wait > 0 || pin.length >= 8) return;
    const next = pin + d;
    setPin(next);
    if (next.length >= 4) {
      // try after each digit from 4 up; a wrong short guess just clears on the 8th digit
      void verifyPin(next).then((ok) => {
        if (ok) onUnlock();
        else if (next.length === 8) {
          fails.current += 1;
          setError(true);
          setPin('');
          window.setTimeout(() => setError(false), 700);
        }
      });
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-6 bg-gradient-to-b from-emerald-700 to-teal-900 px-6 text-white">
      <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/15 backdrop-blur">
        <Lock className="h-8 w-8" />
      </span>
      <div className="text-center">
        <h1 className="text-xl font-bold">{bn ? 'অ্যাপ লক করা আছে' : 'App is locked'}</h1>
        <p className="mt-1 text-sm text-emerald-100">
          {wait > 0
            ? bn ? `${wait} সেকেন্ড পরে আবার চেষ্টা করুন` : `Try again in ${wait}s`
            : bn ? 'আপনার পিন দিন' : 'Enter your PIN'}
        </p>
      </div>
      <div className={`flex h-4 items-center gap-3 ${error ? 'animate-shake' : ''}`} aria-live="polite">
        {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
          <span key={i} className={`h-3.5 w-3.5 rounded-full border-2 border-white ${i < pin.length ? 'bg-white' : ''} ${error ? 'border-red-300 bg-red-300' : ''}`} />
        ))}
      </div>
      <div className="grid w-full max-w-[17rem] grid-cols-3 gap-3">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
          <button key={d} type="button" onClick={() => press(d)} className="h-16 rounded-2xl bg-white/10 text-2xl font-semibold active:bg-white/30">
            {d}
          </button>
        ))}
        <span />
        <button type="button" onClick={() => press('0')} className="h-16 rounded-2xl bg-white/10 text-2xl font-semibold active:bg-white/30">0</button>
        <button type="button" onClick={() => setPin((p) => p.slice(0, -1))} aria-label="Delete" className="flex h-16 items-center justify-center rounded-2xl text-white/80 active:bg-white/20">
          <Delete className="h-6 w-6" />
        </button>
      </div>
      <button type="button" onClick={() => void submit(pin)} disabled={pin.length < 4 || wait > 0} className="rounded-xl bg-white px-8 py-2.5 text-sm font-semibold text-emerald-800 disabled:opacity-40">
        {bn ? 'আনলক' : 'Unlock'}
      </button>
      <button
        type="button"
        onClick={() => {
          const msg = bn
            ? 'পিন ভুলে গেলে এই ফোনের সব মেস-ডাটা মুছে অ্যাপ নতুন করে শুরু করতে হবে (ব্যাকআপ ফাইল থাকলে পরে রিস্টোর করা যাবে)। চালিয়ে যাবেন?'
            : 'Resetting erases ALL mess data on this phone (you can restore later from a backup file). Continue?';
          if (window.confirm(msg)) onReset();
        }}
        className="text-xs text-emerald-100/90 underline underline-offset-2"
      >
        {bn ? 'পিন ভুলে গেছেন?' : 'Forgot PIN?'}
      </button>
    </div>
  );
}
