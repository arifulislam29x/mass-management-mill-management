import React, { Suspense, lazy, useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  BarChart3,
  Calendar,
  Code2,
  Download,
  FileSpreadsheet,
  Globe,
  LayoutDashboard,
  Menu,
  Moon,
  Receipt,
  RefreshCw,
  Settings,
  ShoppingBasket,
  Sun,
  Users,
  Utensils,
  Wallet,
  X,
} from 'lucide-react';
import type { Language, MonthlyOverview, NavTab, ThemeMode } from './types.ts';
import { apiRequest, errorText } from './lib/api.ts';
import { StoreCorruptError, flush, getMeta, getState, initStore, updateMeta, wipeAll } from './lib/local/store.ts';
import { hasPin } from './lib/local/lock.ts';
import { useResponsiveTables } from './lib/responsiveTables.ts';
import { registerServiceWorker, useInstallPrompt } from './lib/pwa.ts';
import { formatMonthLabel, tDict } from './lib/i18n.ts';
import { DeveloperCard, DeveloperFooter } from './components/DeveloperCredit.tsx';
import { UpdateBanner } from './components/InstallBanner.tsx';
import { InstallPopup } from './components/InstallPopup.tsx';
import { LockScreen } from './components/LockScreen.tsx';
import { Onboarding } from './components/Onboarding.tsx';
import { OverviewTab } from './components/OverviewTab.tsx';
import { DashboardSkeleton, ErrorBoundary, Modal, ToastBanner } from './components/ui.tsx';

const AdminSettingsTab = lazy(() => import('./components/AdminSettingsTab.tsx').then((m) => ({ default: m.AdminSettingsTab })));
const BazarTab = lazy(() => import('./components/BazarTab.tsx').then((m) => ({ default: m.BazarTab })));
const DepositsTab = lazy(() => import('./components/DepositsTab.tsx').then((m) => ({ default: m.DepositsTab })));
const ExpensesTab = lazy(() => import('./components/ExpensesTab.tsx').then((m) => ({ default: m.ExpensesTab })));
const MealsTab = lazy(() => import('./components/MealsTab.tsx').then((m) => ({ default: m.MealsTab })));
const MembersTab = lazy(() => import('./components/MembersTab.tsx').then((m) => ({ default: m.MembersTab })));
const ReportsTab = lazy(() => import('./components/ReportsTab.tsx').then((m) => ({ default: m.ReportsTab })));

const VALID_TABS: NavTab[] = ['overview', 'members', 'meals', 'bazar', 'expenses', 'deposits', 'reports', 'settings'];
const LOCAL_TOKEN = 'local'; // the tab components expect a token; everything runs on this device

function readStored<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const v = window.localStorage.getItem(key);
    if (v && (allowed as readonly string[]).includes(v)) return v as T;
  } catch {
    /* storage unavailable */
  }
  return fallback;
}

function readInitialTheme(): ThemeMode {
  try {
    if (!window.localStorage.getItem('messview.theme')) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
  } catch {
    /* ignore */
  }
  return readStored<ThemeMode>('messview.theme', ['light', 'dark'], 'light');
}

function tabFromHash(): NavTab {
  const raw = window.location.hash.replace(/^#\/?/, '');
  return VALID_TABS.includes(raw as NavTab) ? (raw as NavTab) : 'overview';
}

function getDefaultMonthKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

type Phase = 'loading' | 'corrupt' | 'onboarding' | 'locked' | 'ready';

function FullScreenMessage({ icon, title, text, children }: { icon: React.ReactNode; title: string; text: string; children?: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50 px-6 text-center dark:bg-slate-950">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-600/30">{icon}</span>
      <h1 className="text-lg font-bold text-slate-900 dark:text-slate-100">{title}</h1>
      {text && <p className="max-w-sm text-sm text-slate-500 dark:text-slate-400">{text}</p>}
      {children}
    </div>
  );
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => readStored<Language>('messview.lang', ['bn', 'en'], 'bn'));
  const [theme, setTheme] = useState<ThemeMode>(readInitialTheme);
  const [phase, setPhase] = useState<Phase>('loading');
  const [corruptKey, setCorruptKey] = useState('');

  const [activeTab, setActiveTab] = useState<NavTab>(tabFromHash);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [devOpen, setDevOpen] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [updateApply, setUpdateApply] = useState<null | (() => void)>(null);

  const [monthKey, setMonthKey] = useState<string>(getDefaultMonthKey());
  const [availableMonths, setAvailableMonths] = useState<string[]>([getDefaultMonthKey()]);
  const [overview, setOverview] = useState<MonthlyOverview | null>(null);
  const [loadingOverview, setLoadingOverview] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [refreshTick, setRefreshTick] = useState(0);

  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [backupNudge, setBackupNudge] = useState(false);

  useResponsiveTables();
  const install = useInstallPrompt();
  const d = tDict(lang);
  const bn = lang === 'bn';
  const authToken = LOCAL_TOKEN;
  const isAdmin = true; // the phone's owner is the admin of their own ledger

  const notify = useCallback((type: 'success' | 'error', message: string) => setToast({ type, message }), []);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  /* ---------------- theme / language / PWA plumbing ---------------- */

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try {
      window.localStorage.setItem('messview.theme', theme);
    } catch {
      /* ignore */
    }
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#0f172a' : '#059669');
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      window.localStorage.setItem('messview.lang', lang);
    } catch {
      /* ignore */
    }
  }, [lang]);

  useEffect(() => {
    registerServiceWorker((apply) => setUpdateApply(() => apply));
  }, []);

  /* ---------------- open the on-device database ---------------- */

  const boot = useCallback(async () => {
    setPhase('loading');
    try {
      await initStore();
      const meta = getMeta();
      const hasData = getState().members.length > 0;
      if (!meta.onboarded && !hasData) setPhase('onboarding');
      else setPhase(hasPin() ? 'locked' : 'ready');
    } catch (err) {
      if (err instanceof StoreCorruptError) setCorruptKey(err.message);
      setPhase('corrupt');
    }
  }, []);

  useEffect(() => {
    void boot();
  }, [boot]);

  const triggerRefresh = useCallback(() => setRefreshTick((t) => t + 1), []);

  // Another tab/window of the app changed the data
  useEffect(() => {
    const h = () => triggerRefresh();
    window.addEventListener('messview:external-change', h);
    return () => window.removeEventListener('messview:external-change', h);
  }, [triggerRefresh]);

  // Make sure the last change is written when the app is closed or backgrounded
  useEffect(() => {
    const h = () => void flush();
    window.addEventListener('pagehide', h);
    document.addEventListener('visibilitychange', h);
    return () => {
      window.removeEventListener('pagehide', h);
      document.removeEventListener('visibilitychange', h);
    };
  }, []);

  /* ---------------- routing (#tab) ---------------- */

  useEffect(() => {
    const want = `#${activeTab}`;
    if (window.location.hash !== want) window.history.replaceState(null, '', want);
    window.scrollTo({ top: 0 });
  }, [activeTab]);

  useEffect(() => {
    const onHash = () => setActiveTab(tabFromHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  /* ---------------- dashboard data ---------------- */

  const loadDashboardData = useCallback(async () => {
    if (phase !== 'ready') return;
    setLoadingOverview(true);
    try {
      const [monthsRes, overviewRes] = await Promise.all([
        apiRequest<{ currentMonth: string; months: string[] }>('/api/public/months'),
        apiRequest<MonthlyOverview>(`/api/public/overview?month=${encodeURIComponent(monthKey)}`),
      ]);
      setAvailableMonths(monthsRes.months);
      setOverview(overviewRes);
      setLoadError(null);
    } catch (err) {
      const msg = errorText(err, bn);
      setLoadError(msg);
      notify('error', msg);
    } finally {
      setLoadingOverview(false);
    }
  }, [phase, monthKey, notify, bn]);

  useEffect(() => {
    void loadDashboardData();
  }, [loadDashboardData, refreshTick]);

  // Gentle reminder to save a backup file (the only copy of the data is on this phone)
  useEffect(() => {
    if (phase !== 'ready') return;
    const last = getMeta().lastBackupAt;
    const days = last ? (Date.now() - Date.parse(last)) / 86_400_000 : Infinity;
    setBackupNudge(getState().members.length > 0 && days > 14);
  }, [phase, refreshTick]);

  const messName =
    (overview && (lang === 'bn' ? overview.settings.mess_name_bn || overview.settings.mess_name : overview.settings.mess_name)) || null;
  const currency = overview?.settings.currency_symbol || '৳';

  useEffect(() => {
    document.title = messName ? `${messName} · Messview` : 'Messview — Mess Management';
  }, [messName]);

  const navItems: Array<{ id: NavTab; label: string; icon: React.ReactNode }> = [
    { id: 'overview', label: d.nav.overview, icon: <LayoutDashboard className="h-4 w-4" /> },
    { id: 'members', label: d.nav.members, icon: <Users className="h-4 w-4" /> },
    { id: 'meals', label: d.nav.meals, icon: <Utensils className="h-4 w-4" /> },
    { id: 'bazar', label: d.nav.bazar, icon: <ShoppingBasket className="h-4 w-4" /> },
    { id: 'expenses', label: d.nav.expenses, icon: <Receipt className="h-4 w-4" /> },
    { id: 'deposits', label: d.nav.deposits, icon: <Wallet className="h-4 w-4" /> },
    { id: 'reports', label: d.nav.reports, icon: <FileSpreadsheet className="h-4 w-4" /> },
    { id: 'settings', label: d.nav.settings, icon: <Settings className="h-4 w-4" /> },
  ];
  const visibleNavItems = navItems;
  const bottomNavIds: NavTab[] = ['overview', 'meals', 'bazar', 'deposits'];
  const bottomNavItems = visibleNavItems.filter((i) => bottomNavIds.includes(i.id));

  const handleSelectNav = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };
  const handleInspectMember = (memberId: number) => {
    setSelectedMemberId(memberId);
    setActiveTab('members');
  };
  const toggleLang = () => setLang((p) => (p === 'bn' ? 'en' : 'bn'));
  const toggleTheme = () => setTheme((p) => (p === 'light' ? 'dark' : 'light'));

  /* ---------------- install popup: offer once, politely ---------------- */

  useEffect(() => {
    if (phase !== 'ready' || install.installed) return;
    if (Date.now() < getMeta().installSnoozedUntil) return;
    const t = window.setTimeout(() => setInstallOpen(true), 2500);
    return () => window.clearTimeout(t);
  }, [phase, install.installed]);

  const closeInstall = () => {
    setInstallOpen(false);
    void updateMeta({ installSnoozedUntil: Date.now() + 3 * 86_400_000 });
  };

  /* ---------------- recovery helpers ---------------- */

  const resetEverything = async () => {
    await wipeAll();
    window.location.reload();
  };

  /* ---------------- screens ---------------- */

  if (phase === 'loading') {
    return (
      <FullScreenMessage icon={<BarChart3 className="h-7 w-7 animate-pulse" />} title="Messview" text="" />
    );
  }

  if (phase === 'corrupt') {
    return (
      <FullScreenMessage
        icon={<AlertTriangle className="h-7 w-7" />}
        title={bn ? 'সংরক্ষিত ডাটা পড়া যায়নি' : 'Could not read saved data'}
        text={
          bn
            ? 'আপনার ডাটা মোছা হয়নি — একটি নিরাপদ কপি রাখা আছে। অ্যাপটি বন্ধ করে আবার খুলে দেখুন। না হলে নতুন করে শুরু করে ব্যাকআপ ফাইল থেকে ফেরান।'
            : 'Your data was not deleted — a safe copy was kept. Close and reopen the app. If that fails, start fresh and restore from a backup file.'
        }
      >
        <p className="font-mono text-[10px] text-slate-400">{corruptKey}</p>
        <div className="flex gap-2">
          <button type="button" onClick={() => void boot()} className="rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white">
            {bn ? 'আবার চেষ্টা' : 'Retry'}
          </button>
          <button type="button" onClick={() => window.confirm(bn ? 'নতুন করে শুরু করবেন? (নিরাপদ কপি থাকবে)' : 'Start fresh? (the safe copy is kept)') && void resetEverything()} className="rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 dark:border-slate-600 dark:text-slate-200">
            {bn ? 'নতুন করে শুরু' : 'Start fresh'}
          </button>
        </div>
      </FullScreenMessage>
    );
  }

  if (phase === 'onboarding') {
    return (
      <>
        <Onboarding
          lang={lang}
          onToggleLang={toggleLang}
          onDone={(l) => {
            setLang(l);
            setPhase('ready');
            triggerRefresh();
          }}
        />
        <InstallPopup lang={lang} open={installOpen} onClose={closeInstall} />
        {updateApply && <UpdateBanner lang={lang} onApply={updateApply} onDismiss={() => setUpdateApply(null)} />}
      </>
    );
  }

  if (phase === 'locked') {
    return (
      <LockScreen
        lang={lang}
        onUnlock={() => setPhase('ready')}
        onReset={() => void resetEverything()}
      />
    );
  }

  const controls = (
    <>
      <button
        type="button"
        onClick={toggleLang}
        className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
        title="Switch Language"
      >
        <Globe className="h-3.5 w-3.5" />
        <span>{lang === 'bn' ? 'EN' : 'বাংলা'}</span>
      </button>
      <button
        type="button"
        onClick={toggleTheme}
        className="inline-flex shrink-0 items-center rounded-lg border border-slate-200 bg-white p-2 text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
        aria-label={theme === 'light' ? d.header.darkMode : d.header.lightMode}
        title={theme === 'light' ? d.header.darkMode : d.header.lightMode}
      >
        {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
      </button>
    </>
  );

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-slate-950/50 lg:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`no-print fixed inset-y-0 left-0 z-50 flex w-72 max-w-[85vw] flex-col border-r border-slate-200 bg-white transition-transform duration-200 dark:border-slate-800 dark:bg-slate-900 lg:static lg:z-auto lg:w-64 lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Main navigation"
      >
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-slate-200 px-5 pt-[env(safe-area-inset-top)] dark:border-slate-800">
          <button type="button" onClick={() => handleSelectNav('overview')} className="flex min-w-0 items-center gap-2.5 text-left">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm shadow-emerald-600/30">
              <BarChart3 className="h-4 w-4" />
            </span>
            <span className="truncate text-base font-bold tracking-tight">{messName || 'Messview'}</span>
          </button>
          <button type="button" onClick={() => setMobileMenuOpen(false)} className="rounded-lg p-1.5 text-slate-500 lg:hidden" aria-label="Close navigation">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {visibleNavItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectNav(item.id)}
                aria-current={active ? 'page' : undefined}
                className={`flex w-full items-center gap-3 whitespace-nowrap rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors ${
                  active
                    ? 'bg-emerald-50 text-emerald-700 shadow-[inset_3px_0_0_0_#059669] dark:bg-emerald-950/60 dark:text-emerald-400 dark:shadow-[inset_3px_0_0_0_#34d399]'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                }`}
              >
                {item.icon}
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="space-y-3 border-t border-slate-200 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] text-xs dark:border-slate-800">
          <div className="flex items-center gap-2 lg:hidden">{controls}</div>
          {!install.installed && (
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setInstallOpen(true);
              }}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-3 py-2.5 font-semibold text-white shadow-sm shadow-emerald-600/30 hover:bg-emerald-700"
            >
              <Download className="h-3.5 w-3.5" />
              {bn ? 'অ্যাপ ইনস্টল / ডাউনলোড' : 'Install / download app'}
            </button>
          )}
          <p className="flex items-center gap-1.5 text-[11px] leading-snug text-slate-500 dark:text-slate-400">
            <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
            {bn ? 'ডাটা শুধু এই ফোনে সংরক্ষিত' : 'Data is stored only on this device'}
          </p>
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              setDevOpen(true);
            }}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-slate-900 px-3 py-2 font-medium text-white hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700"
          >
            <Code2 className="h-3.5 w-3.5" />
            {bn ? 'ডেভেলপার ইনফো' : 'About the developer'}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="no-print sticky top-0 z-30 flex min-h-16 items-center justify-between gap-2 border-b border-slate-200 bg-white/95 px-3 pt-[env(safe-area-inset-top)] backdrop-blur-xs dark:border-slate-800 dark:bg-slate-900/95 sm:gap-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-2 sm:gap-3">
            <button type="button" onClick={() => setMobileMenuOpen(true)} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 lg:hidden" aria-label="Open menu">
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0">
              <h1 className="truncate text-base font-semibold">{navItems.find((i) => i.id === activeTab)?.label}</h1>
              {overview && (
                <p className="hidden truncate text-xs text-slate-500 dark:text-slate-400 sm:block">
                  {formatMonthLabel(monthKey, lang)} · {overview.isClosed ? d.header.monthClosed : d.header.monthOpen}
                </p>
              )}
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
            <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1.5 dark:border-slate-700 dark:bg-slate-800">
              <Calendar className="hidden h-3.5 w-3.5 text-slate-500 sm:block" />
              <input
                type="month"
                aria-label={d.header.selectMonth}
                value={monthKey}
                onChange={(e) => e.target.value && setMonthKey(e.target.value)}
                list="available-months-list"
                className="w-[7.2rem] bg-transparent font-mono text-xs font-medium text-slate-800 focus:outline-none dark:text-slate-100 sm:w-auto"
              />
              <datalist id="available-months-list">
                {availableMonths.map((mk) => (
                  <option key={mk} value={mk} />
                ))}
              </datalist>
            </div>

            {!install.installed && (
              <button
                type="button"
                onClick={() => setInstallOpen(true)}
                className="hidden shrink-0 items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-300 lg:inline-flex"
              >
                <Download className="h-3.5 w-3.5" />
                {bn ? 'অ্যাপ নিন' : 'Get app'}
              </button>
            )}
            <div className="hidden items-center gap-2 sm:flex">{controls}</div>
          </div>
        </header>

        {backupNudge && (
          <button
            type="button"
            onClick={() => handleSelectNav('settings')}
            className="no-print flex w-full items-center justify-center gap-2 bg-amber-100 px-4 py-2 text-center text-xs font-medium text-amber-900 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-100"
          >
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            {bn ? 'ডাটা শুধু এই ফোনে আছে — সেটিংস থেকে একটি ব্যাকআপ ফাইল সেভ করে রাখুন।' : 'Your data lives only on this phone — save a backup file from Settings.'}
          </button>
        )}

        <main className="mx-auto w-full max-w-[1440px] flex-1 p-3 pb-28 sm:p-6 lg:pb-6">
          {loadingOverview && !overview && !loadError ? (
            <DashboardSkeleton />
          ) : !overview && loadError ? (
            <div className="mx-auto flex max-w-xl flex-col items-center rounded-2xl border border-slate-200 bg-white px-6 py-14 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <AlertTriangle className="h-10 w-10 text-red-500" />
              <h2 className="mt-4 text-lg font-semibold">{bn ? 'ডাটা লোড করা যায়নি' : 'Could not load data'}</h2>
              <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{loadError}</p>
              <button type="button" onClick={triggerRefresh} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white">
                <RefreshCw className={`h-4 w-4 ${loadingOverview ? 'animate-spin' : ''}`} />
                {bn ? 'আবার চেষ্টা করুন' : 'Try again'}
              </button>
            </div>
          ) : (
            <ErrorBoundary lang={lang} key={activeTab}>
              <Suspense fallback={<DashboardSkeleton />}>
                <div className="page-enter">
                  {activeTab === 'overview' && overview && (
                    <OverviewTab
                      overview={overview}
                      currency={currency}
                      lang={lang}
                      isAdmin={isAdmin}
                      onNavigate={setActiveTab}
                      onOpenAuth={() => undefined}
                      onSelectMember={handleInspectMember}
                    />
                  )}

                  {activeTab === 'members' && (
                    <MembersTab
                      monthKey={monthKey}
                      currency={currency}
                      lang={lang}
                      isAdmin={isAdmin}
                      authToken={authToken}
                      selectedMemberId={selectedMemberId}
                      onClearSelectedMember={() => setSelectedMemberId(null)}
                      onDataChanged={triggerRefresh}
                      onNotify={notify}
                    />
                  )}

                  {activeTab === 'meals' && (
                    <MealsTab monthKey={monthKey} lang={lang} isAdmin={isAdmin} authToken={authToken} onDataChanged={triggerRefresh} onNotify={notify} />
                  )}

                  {activeTab === 'bazar' && (
                    <BazarTab monthKey={monthKey} currency={currency} lang={lang} isAdmin={isAdmin} authToken={authToken} onDataChanged={triggerRefresh} onNotify={notify} />
                  )}

                  {activeTab === 'expenses' && (
                    <ExpensesTab monthKey={monthKey} currency={currency} lang={lang} isAdmin={isAdmin} authToken={authToken} onDataChanged={triggerRefresh} onNotify={notify} />
                  )}

                  {activeTab === 'deposits' && (
                    <DepositsTab monthKey={monthKey} currency={currency} lang={lang} isAdmin={isAdmin} authToken={authToken} onDataChanged={triggerRefresh} onNotify={notify} />
                  )}

                  {activeTab === 'reports' && overview && (
                    <ReportsTab overview={overview} currency={currency} lang={lang} isAdmin={isAdmin} authToken={authToken} onDataChanged={triggerRefresh} onNotify={notify} />
                  )}

                  {activeTab === 'settings' && overview && (
                    <AdminSettingsTab
                      settings={overview.settings}
                      lang={lang}
                      authToken={authToken}
                      onDataChanged={triggerRefresh}
                      onNotify={notify}
                    />
                  )}
                </div>
              </Suspense>
            </ErrorBoundary>
          )}
          <DeveloperFooter lang={lang} className="mt-10" />
        </main>
      </div>

      {/* Mobile bottom navigation */}
      <nav
        className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-xs dark:border-slate-800 dark:bg-slate-900/95 lg:hidden"
        aria-label="Quick navigation"
      >
        <ul className="grid grid-cols-5">
          {bottomNavItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => handleSelectNav(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`flex w-full flex-col items-center gap-0.5 px-1 py-2 text-[11px] font-medium ${
                    active ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  <span className={`rounded-full px-4 py-1 ${active ? 'bg-emerald-100 dark:bg-emerald-950' : ''}`}>{item.icon}</span>
                  <span className="max-w-full truncate">{item.label}</span>
                </button>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="flex w-full flex-col items-center gap-0.5 px-1 py-2 text-[11px] font-medium text-slate-500 dark:text-slate-400"
            >
              <span className="rounded-full px-4 py-1">
                <Menu className="h-4 w-4" />
              </span>
              <span>{bn ? 'আরও' : 'More'}</span>
            </button>
          </li>
        </ul>
      </nav>

      <Modal open={devOpen} onClose={() => setDevOpen(false)} title={bn ? 'ডেভেলপার ইনফো' : 'About the developer'} maxWidthClass="max-w-md">
        <DeveloperCard lang={lang} className="border-0 shadow-none" />
      </Modal>
      <InstallPopup lang={lang} open={installOpen} onClose={closeInstall} />
      <ToastBanner toast={toast} onDismiss={() => setToast(null)} />
      {updateApply && <UpdateBanner lang={lang} onApply={updateApply} onDismiss={() => setUpdateApply(null)} />}
    </div>
  );
}
