/* Messview service worker
 * - Precaches the whole built app (list written at build time to /precache.json) so it opens
 *   offline from the very first visit.
 * - A new build id => new cache => the app shows an "Update" banner (see src/lib/pwa.ts).
 * - Nothing about the user's ledger ever passes through here: it lives in IndexedDB on the phone.
 */
const BUILD = '__BUILD_ID__';
const CACHE = `messview-${BUILD}`;
const CORE = ['/', '/manifest.webmanifest', '/favicon.svg', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      let files = [];
      try {
        const res = await fetch('/precache.json', { cache: 'no-store' });
        if (res.ok) files = (await res.json()).files || [];
      } catch (e) {
        /* offline during install: fall back to the core list */
      }
      const urls = Array.from(new Set(CORE.concat(files)));
      // Individually, so one missing file never blocks the install.
      await Promise.all(urls.map((u) => cache.add(u).catch(() => undefined)));
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  // Never cache the APK or its info file: they must always be the latest.
  if (url.pathname.endsWith('.apk') || url.pathname === '/apk-info.json' || url.pathname === '/precache.json') return;

  if (req.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const res = await fetch(req);
          if (res.ok) caches.open(CACHE).then((c) => c.put('/', res.clone()));
          return res;
        } catch (e) {
          return (await caches.match('/')) || Response.error();
        }
      })()
    );
    return;
  }

  event.respondWith(
    (async () => {
      const hit = await caches.match(req);
      if (hit) return hit;
      try {
        const res = await fetch(req);
        if (res.ok && res.type === 'basic') caches.open(CACHE).then((c) => c.put(req, res.clone()));
        return res;
      } catch (e) {
        return Response.error();
      }
    })()
  );
});
