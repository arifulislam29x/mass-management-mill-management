import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      // Offline + update support: list every built file for the service worker and stamp a build id.
      {
        name: 'messview-precache',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) return;
          try {
            const distDir = path.resolve(__dirname, 'dist');
            const files: string[] = [];
            const walk = (dir: string) => {
              for (const name of fs.readdirSync(dir)) {
                const full = path.join(dir, name);
                if (fs.statSync(full).isDirectory()) walk(full);
                else files.push('/' + path.relative(distDir, full).split(path.sep).join('/'));
              }
            };
            walk(distDir);
            const skip = /^\/(sw\.js|precache\.json|apk-info\.json|_redirects|_headers)$|\.apk$|^\/\.well-known\/|\.map$/;
            const list = files.filter((f) => !skip.test(f)).sort();
            const buildId = Date.now().toString(36);
            fs.writeFileSync(path.join(distDir, 'precache.json'), JSON.stringify({ buildId, files: list }));
            const swPath = path.join(distDir, 'sw.js');
            if (fs.existsSync(swPath)) {
              fs.writeFileSync(swPath, fs.readFileSync(swPath, 'utf8').replace('__BUILD_ID__', buildId));
            }
          } catch (e) {
            console.warn('[messview-precache] skipped:', e);
          }
        },
      },
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
        },
      },
    ],
    build: {
      chunkSizeWarningLimit: 700,
      rolldownOptions: {
        output: {
          codeSplitting: {
            groups: [
              { name: 'pdf', test: /node_modules[\\/](jspdf|jspdf-autotable|html2canvas|canvg|dompurify)/, priority: 30 },
              { name: 'excel', test: /node_modules[\\/]exceljs/, priority: 30 },
              { name: 'motion', test: /node_modules[\\/](motion|framer-motion|motion-dom|motion-utils)/, priority: 20 },
              { name: 'vendor', test: /node_modules[\\/](react|react-dom|scheduler|lucide-react)/, priority: 10 },
            ],
          },
        },
      },
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
