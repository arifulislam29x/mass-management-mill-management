# MessLedger — Netlify deploy guide

## কেন আগের সাইটে শুধু কালো/ফাঁকা স্ক্রিন দেখা যেতে পারে
এই ZIP-এর আগের সংস্করণে সব source file `Mess-Managment-app-main/` নামের subfolder-এর ভিতরে ছিল। Netlify-তে Git repository root হিসেবে deploy করলে Netlify root-এ `package.json`/`netlify.toml` না পেয়ে ভুল build/publish directory নিতে পারে। আবার ZIP-এর source সরাসরি Drag & Drop করলে React/TypeScript source browser-এ চালানোর মতো build করা হয় না।

এই ZIP-এ project files root-এ রাখা হয়েছে। Netlify-তে GitHub repository হিসেবে deploy করলে repository root-ই Base directory হবে।

## Netlify সেটিংস
- Base directory: ফাঁকা রাখুন (repository root)
- Build command: `npm run build`
- Publish directory: `dist`
- Node version: 22 (netlify.toml-এ নির্ধারিত)
- Environment variable: `VITE_API_BASE_URL=https://YOUR-BACKEND-DOMAIN`

তারপর **Clear cache and deploy site** দিয়ে নতুন deploy দিন। Source ZIP সরাসরি Published folder হিসেবে upload করবেন না।

## Backend ও SQLite
Netlify static frontend host করে; এটি Express server বা persistent SQLite database চালায় না। `server.ts`-কে Render/Railway/VPS-এর মতো Node.js host-এ চালাতে হবে এবং persistent disk-এ `DB_PATH` দিতে হবে। Backend environment:
- `NODE_ENV=production`
- `DB_PATH=/var/data/mess.db` (host-এর persistent disk path)
- `ALLOWED_ORIGIN=https://YOUR-NETLIFY-SITE.netlify.app`
- `ADMIN_USERNAME=...`
- `ADMIN_PASSWORD=...`
- `SESSION_SECRET=...`

Backend চালু হলে `https://YOUR-BACKEND-DOMAIN/api/health` খুলে `{"status":"ok"...}` পাওয়া উচিত। Netlify-তে `VITE_API_BASE_URL` সেট করার পর frontend আবার build/deploy করতে হবে।

## যদি এখনো ফাঁকা থাকে
1. Netlify → Deploys → সর্বশেষ deploy → Deploy log-এ `vite build` সফল এবং `dist` তৈরি হয়েছে কি না দেখুন।
2. Deploy file browser-এ `index.html` এবং `assets/` folder আছে কি না দেখুন।
3. ব্রাউজারে Ctrl+Shift+R দিন; পুরোনো PWA cache থাকলে DevTools → Application → Service Workers থেকে Unregister এবং Clear site data করুন।
4. F12 → Console-এর প্রথম লাল error এবং Network-এ `/assets/*.js` request-এর status পরীক্ষা করুন।
5. `/api/health` ব্যর্থ হলে backend URL/hosting ঠিক করুন।

## Android APK
এই Netlify deploy হলো installable PWA; এটি APK ফাইল নয়। APK বানাতে আলাদা Android wrapper/build/signing workflow দরকার।
